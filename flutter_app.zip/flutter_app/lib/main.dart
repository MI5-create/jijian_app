import 'package:flutter/material.dart';


import 'controllers/favorites_controller.dart';
import 'pages/home_page.dart'; // 这里包含 AppColors 等公用组件
import 'pages/brand_page.dart';
import 'pages/search_page.dart';
import 'pages/favorites_page.dart';
import 'pages/profile_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 防白屏终极防线
  ErrorWidget.builder = (FlutterErrorDetails details) {
    return Container(
      color: const Color(0xFF070B14),
      alignment: Alignment.center,
      padding: const EdgeInsets.all(20),
      child: Text(
        '渲染发生异常:\n${details.exception}',
        style: const TextStyle(color: Colors.redAccent, fontSize: 14),
      ),
    );
  };

  final favorites = FavoritesController();
  
  // 安全加载
  try {
    await favorites.load().timeout(const Duration(seconds: 3));
  } catch (e) {
    debugPrint('本地存储初始化失败: $e');
  }

  runApp(JijianApp(favorites: favorites));
}

class JijianApp extends StatelessWidget {
  final FavoritesController favorites;
  const JijianApp({super.key, required this.favorites});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '机鉴',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: AppColors.bgBase,
      ),
      home: MainShell(favorites: favorites),
    );
  }
}

class MainShell extends StatefulWidget {
  final FavoritesController favorites;
  const MainShell({super.key, required this.favorites});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgBase,
      body: SafeArea(
        child: IndexedStack(
          index: _index,
          children: [
            HomePage(favorites: widget.favorites),
            // 这里传入了收藏状态
            BrandPage(favorites: widget.favorites),
            SearchPage(favorites: widget.favorites),
            FavoritesPage(favorites: widget.favorites),
            const ProfilePage(),
          ],
        ),
      ),
      
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: const Color(0xFFF5F7FA), // 或者改成 Colors.white
          border: Border(top: BorderSide(color: Colors.white.withValues(alpha: 0.08), width: 0.5)),
        ),
        child: BottomNavigationBar(
          currentIndex: _index,
          onTap: (i) => setState(() => _index = i),
          backgroundColor: Colors.transparent,
          elevation: 0,
          selectedItemColor: AppColors.primary,
          unselectedItemColor: AppColors.textTertiary,
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: '首页'),
            BottomNavigationBarItem(icon: Icon(Icons.grid_view), label: '品牌'),
            BottomNavigationBarItem(icon: Icon(Icons.search), label: '搜索'),
            BottomNavigationBarItem(icon: Icon(Icons.bookmark), label: '收藏'),
            BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: '我的'),
          ],
        ),
      ),
    );
  }
}