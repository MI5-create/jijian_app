import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final favorites = FavoritesController();
  await favorites.load();
  runApp(JijianApp(favorites: favorites));
}

// ============================================================
// App 入口与主壳
// ============================================================

class JijianApp extends StatelessWidget {
  final FavoritesController favorites;

  const JijianApp({super.key, required this.favorites});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '机鉴 · 手机图鉴',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: MainShell(favorites: favorites),
    );
  }
}

class MainShell extends StatefulWidget {
  final FavoritesController favorites;

  const MainShell({super.key, required this.favorites});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  void _switchTo(int index) {
    if (_index == index) return;
    setState(() => _index = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgBase,
      body: IndexedStack(
        index: _index,
        children: [
          HomePage(
            favorites: widget.favorites,
            onSearchTap: () => _switchTo(2),
          ),
          BrandsPage(favorites: widget.favorites),
          SearchPage(favorites: widget.favorites),
          FavoritesPage(favorites: widget.favorites),
          ProfilePage(favorites: widget.favorites),
        ],
      ),
      bottomNavigationBar: GlassBottomNav(
        currentIndex: _index,
        onTap: _switchTo,
      ),
    );
  }
}

// ============================================================
// 收藏状态管理
// ============================================================

class FavoritesController extends ChangeNotifier {
  static const _prefsKey = 'favorite_phone_ids';

  final Set<String> _ids = <String>{};

  Set<String> get ids => Set.unmodifiable(_ids);

  int get count => _ids.length;

  bool isFavorite(String id) => _ids.contains(id);

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getStringList(_prefsKey) ?? const <String>[];
    _ids
      ..clear()
      ..addAll(stored);
    notifyListeners();
  }

  Future<void> toggle(String id) async {
    if (_ids.contains(id)) {
      _ids.remove(id);
    } else {
      _ids.add(id);
    }
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    final sorted = _ids.toList()..sort();
    await prefs.setStringList(_prefsKey, sorted);
  }
}

// ============================================================
// 主题 Token
// ============================================================

class AppColors {
  AppColors._();

  static const bgBase = Color(0xFF070B14);
  static const bgElevated = Color(0xFF0B1220);

  static const surface1 = Color(0xFF101A2C);
  static const surface2 = Color(0xFF15223A);
  static const surface3 = Color(0xFF1B2B47);

  static const glassFillLow = Color.fromRGBO(18, 30, 52, 0.54);
  static const glassFillMedium = Color.fromRGBO(18, 30, 52, 0.62);
  static const glassFillHigh = Color.fromRGBO(24, 38, 64, 0.70);

  static const glassStrokeTop = Color.fromRGBO(255, 255, 255, 0.28);
  static const glassStrokeBottom = Color.fromRGBO(255, 255, 255, 0.06);

  static const primary = Color(0xFF45D6FF);
  static const primaryPressed = Color(0xFF2BBBE6);
  static const primarySoft = Color.fromRGBO(69, 214, 255, 0.14);
  static const violet = Color(0xFF9B7BFF);
  static const violetPressed = Color(0xFF7F5DF0);
  static const violetSoft = Color.fromRGBO(155, 123, 255, 0.14);
  static const accentOrange = Color(0xFFFFB05C);
  static const accentOrangeSoft = Color.fromRGBO(255, 176, 92, 0.12);

  static const textPrimary = Color(0xFFF4F8FF);
  static const textSecondary = Color(0xFFB7C4D9);
  static const textTertiary = Color(0xFF7C8AA3);
  static const textOnGlass = Color(0xFFEAF2FF);
  static const textOnAccent = Color(0xFF06121F);

  static const success = Color(0xFF3DDC97);
  static const warning = Color(0xFFFFC266);
  static const error = Color(0xFFFF6B81);
}

class AppSpacing {
  AppSpacing._();
  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 20.0;
  static const xxl = 24.0;
  static const xxxl = 32.0;
}

class AppRadius {
  AppRadius._();
  static const sm = 12.0;
  static const md = 16.0;
  static const lg = 20.0;
  static const xl = 24.0;
  static const pill = 999.0;
}

class AppShadows {
  AppShadows._();
  static const card = BoxShadow(
    color: Color.fromRGBO(0, 0, 0, 0.32),
    blurRadius: 32,
    offset: Offset(0, 12),
  );
}

class GlassTokens {
  GlassTokens._();
  static const double blurLow = 16;
  static const double blurMedium = 24;
  static const double blurHigh = 32;
}

class MotionTokens {
  MotionTokens._();
  static const press = Duration(milliseconds: 120);
  static const base = Duration(milliseconds: 300);
  static const curveStandard = Cubic(0.2, 0.8, 0.2, 1);
}

ThemeData buildAppTheme() {
  final base = ThemeData.dark(useMaterial3: true);

  return base.copyWith(
    scaffoldBackgroundColor: AppColors.bgBase,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.primary,
      secondary: AppColors.violet,
      surface: AppColors.surface1,
      error: AppColors.error,
      onPrimary: AppColors.textOnAccent,
      onSurface: AppColors.textPrimary,
    ),
    textTheme: const TextTheme(
      displayLarge: TextStyle(
        fontSize: 32,
        height: 40 / 32,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.4,
        color: AppColors.textPrimary,
      ),
      headlineMedium: TextStyle(
        fontSize: 24,
        height: 32 / 24,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.2,
        color: AppColors.textPrimary,
      ),
      titleMedium: TextStyle(
        fontSize: 17,
        height: 24 / 17,
        fontWeight: FontWeight.w600,
        color: AppColors.textPrimary,
      ),
      bodyMedium: TextStyle(
        fontSize: 15,
        height: 22 / 15,
        fontWeight: FontWeight.w400,
        color: AppColors.textPrimary,
      ),
      labelMedium: TextStyle(
        fontSize: 13,
        height: 18 / 13,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.1,
        color: AppColors.textSecondary,
      ),
      bodySmall: TextStyle(
        fontSize: 12,
        height: 18 / 12,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.1,
        color: AppColors.textSecondary,
      ),
      labelSmall: TextStyle(
        fontSize: 11,
        height: 16 / 11,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.1,
        color: AppColors.textTertiary,
      ),
    ),
  );
}

// ============================================================
// 数据模型：Phone
// ============================================================

class Phone {
  final String brand;
  final String name;
  final String releaseDate;
  final String chipset;
  final String screen;
  final String battery;
  final String sourceUrl;

  const Phone({
    required this.brand,
    required this.name,
    required this.releaseDate,
    required this.chipset,
    required this.screen,
    required this.battery,
    required this.sourceUrl,
  });

  String get id => '$brand::$name';

  String get displayReleaseDate {
    final parts = releaseDate.split('-');
    if (parts.length == 2) {
      final year = parts[0];
      final month = int.tryParse(parts[1]);
      if (month != null) return '$year 年 $month 月';
    }
    return releaseDate;
  }

  String get displayDomain {
    try {
      return Uri.parse(sourceUrl).host;
    } catch (_) {
      return sourceUrl;
    }
  }
}

// ============================================================
// 全量机型数据
// ============================================================

final List<Phone> allPhones = const [
  // ---------- 华为 ----------
  Phone(
    brand: '华为',
    name: 'Mate 80',
    releaseDate: '2025-11',
    chipset: '麒麟 9020',
    screen: '6.75英寸 OLED',
    battery: '5750mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80/',
  ),
  Phone(
    brand: '华为',
    name: 'Mate 80 Pro',
    releaseDate: '2025-11',
    chipset: '麒麟 9030',
    screen: '6.75英寸 OLED',
    battery: '5750mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80pro/',
  ),
  Phone(
    brand: '华为',
    name: 'Mate 80 Pro Max',
    releaseDate: '2025-11',
    chipset: '麒麟 9030 Pro',
    screen: '6.9英寸 OLED',
    battery: '6000mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80promax/',
  ),
  Phone(
    brand: '华为',
    name: 'Mate 80 RS 非凡大师',
    releaseDate: '2025-11',
    chipset: '麒麟 9030 Pro',
    screen: '6.9英寸 OLED',
    battery: '6000mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80rs/',
  ),
  Phone(
    brand: '华为',
    name: 'Pura 80',
    releaseDate: '2025-06',
    chipset: '麒麟 9010S',
    screen: '6.6英寸 OLED',
    battery: '5600mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/pura80/',
  ),
  Phone(
    brand: '华为',
    name: 'Pura 80 Pro',
    releaseDate: '2025-06',
    chipset: '麒麟 9020',
    screen: '6.8英寸 OLED',
    battery: '5700mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/pura80pro/',
  ),
  Phone(
    brand: '华为',
    name: 'Pura 80 Ultra',
    releaseDate: '2025-06',
    chipset: '麒麟 9020',
    screen: '6.8英寸 OLED',
    battery: '5700mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/pura80ultra/',
  ),
  Phone(
    brand: '华为',
    name: 'Mate X7',
    releaseDate: '2025-11',
    chipset: '麒麟 9020',
    screen: '折叠屏 OLED',
    battery: '5750mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/matex7/',
  ),
  Phone(
    brand: '华为',
    name: 'nova 14',
    releaseDate: '2025-05',
    chipset: '麒麟9010',
    screen: '6.7英寸 OLED',
    battery: '5000mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/nova14/',
  ),
  Phone(
    brand: '华为',
    name: 'Mate XT 非凡大师',
    releaseDate: '2025-04',
    chipset: '麒麟9020',
    screen: '三折叠屏 OLED',
    battery: '6000mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/matext/',
  ),

  // ---------- 苹果 ----------
  Phone(
    brand: '苹果',
    name: 'iPhone 17',
    releaseDate: '2025-09',
    chipset: 'A19',
    screen: '6.3英寸 OLED',
    battery: '3692mAh',
    sourceUrl: 'https://www.apple.com/iphone-17/',
  ),
  Phone(
    brand: '苹果',
    name: 'iPhone 17 Air',
    releaseDate: '2025-09',
    chipset: 'A19 Pro',
    screen: '6.5英寸 OLED',
    battery: '3149mAh',
    sourceUrl: 'https://www.apple.com/iphone-air/',
  ),
  Phone(
    brand: '苹果',
    name: 'iPhone 17 Pro',
    releaseDate: '2025-09',
    chipset: 'A19 Pro',
    screen: '6.3英寸 OLED',
    battery: '3988mAh',
    sourceUrl: 'https://www.apple.com/iphone-17-pro/',
  ),
  Phone(
    brand: '苹果',
    name: 'iPhone 17 Pro Max',
    releaseDate: '2025-09',
    chipset: 'A19 Pro',
    screen: '6.9英寸 OLED',
    battery: '4832mAh',
    sourceUrl: 'https://www.apple.com/iphone-17-pro-max/',
  ),

  // ---------- 小米 ----------
  Phone(
    brand: '小米',
    name: 'Xiaomi 17',
    releaseDate: '2025-09',
    chipset: '第五代骁龙8至尊版',
    screen: '6.3英寸 OLED',
    battery: '7000mAh',
    sourceUrl: 'https://www.mi.com/xiaomi17/',
  ),
  Phone(
    brand: '小米',
    name: 'Xiaomi 17 Pro',
    releaseDate: '2025-09',
    chipset: '第五代骁龙8至尊版',
    screen: '6.3英寸 OLED（含背屏）',
    battery: '6300mAh',
    sourceUrl: 'https://www.mi.com/xiaomi17pro/',
  ),
  Phone(
    brand: '小米',
    name: 'Xiaomi 17 Pro Max',
    releaseDate: '2025-09',
    chipset: '第五代骁龙8至尊版',
    screen: '6.9英寸 OLED',
    battery: '7500mAh',
    sourceUrl: 'https://www.mi.com/xiaomi17promax/',
  ),
  Phone(
    brand: '小米',
    name: 'Xiaomi 17 Ultra',
    releaseDate: '2026-03',
    chipset: '骁龙8至尊版',
    screen: '6.73英寸 OLED',
    battery: '5500mAh',
    sourceUrl: 'https://www.mi.com/xiaomi17ultra/',
  ),

  // ---------- OPPO ----------
  Phone(
    brand: 'OPPO',
    name: 'Find X9 Ultra',
    releaseDate: '2026-04',
    chipset: '第五代骁龙8至尊版',
    screen: '6.82英寸 2K AMOLED',
    battery: '7050mAh',
    sourceUrl: 'https://www.oppo.com/cn/phones/find-x9-ultra/',
  ),
  Phone(
    brand: 'OPPO',
    name: 'Find X9 Pro',
    releaseDate: '2025-10',
    chipset: '天玑9400+',
    screen: '6.78英寸 AMOLED',
    battery: '5900mAh',
    sourceUrl: 'https://www.oppo.com/cn/phones/find-x9-pro/',
  ),
  Phone(
    brand: 'OPPO',
    name: 'Find X8 Ultra',
    releaseDate: '2025-04',
    chipset: '骁龙8至尊版',
    screen: '6.82英寸 2K AMOLED',
    battery: '6100mAh',
    sourceUrl: 'https://www.oppo.com/cn/phones/find-x8-ultra/',
  ),
  Phone(
    brand: 'OPPO',
    name: 'Reno 15',
    releaseDate: '2025-08',
    chipset: '天玑7300',
    screen: '6.67英寸 OLED',
    battery: '5000mAh',
    sourceUrl: 'https://www.oppo.com/cn/phones/reno15/',
  ),
  Phone(
    brand: 'OPPO',
    name: 'Reno 15 Pro',
    releaseDate: '2025-08',
    chipset: '天玑9300+',
    screen: '6.78英寸 OLED',
    battery: '5500mAh',
    sourceUrl: 'https://www.oppo.com/cn/phones/reno15pro/',
  ),
  Phone(
    brand: 'OPPO',
    name: 'Find N5',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版',
    screen: '折叠屏 AMOLED',
    battery: '5500mAh',
    sourceUrl: 'https://www.oppo.com/cn/phones/find-n5/',
  ),

  // ---------- vivo ----------
  Phone(
    brand: 'vivo',
    name: 'X300 Ultra',
    releaseDate: '2026-03',
    chipset: '第五代骁龙8至尊版',
    screen: '6.82英寸 2K OLED',
    battery: '6600mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/x300-ultra/',
  ),
  Phone(
    brand: 'vivo',
    name: 'X300 Pro',
    releaseDate: '2025-10',
    chipset: '天玑9500',
    screen: '6.78英寸 OLED',
    battery: '6510mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/x300-pro/',
  ),
  Phone(
    brand: 'vivo',
    name: 'X300',
    releaseDate: '2025-10',
    chipset: '天玑9500',
    screen: '6.31英寸 OLED',
    battery: '6040mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/x300/',
  ),
  Phone(
    brand: 'vivo',
    name: 'X200 Ultra',
    releaseDate: '2025-04',
    chipset: '骁龙8至尊版',
    screen: '6.82英寸 2K OLED',
    battery: '6000mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/x200-ultra/',
  ),
  Phone(
    brand: 'vivo',
    name: 'X200s',
    releaseDate: '2025-07',
    chipset: '天玑9400+',
    screen: '6.78英寸 OLED',
    battery: '6000mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/x200s/',
  ),
  Phone(
    brand: 'vivo',
    name: 'S30',
    releaseDate: '2025-05',
    chipset: '天玑9300+',
    screen: '6.67英寸 OLED',
    battery: '5800mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/s30/',
  ),
  Phone(
    brand: 'vivo',
    name: 'S50',
    releaseDate: '2025-12',
    chipset: '第三代骁龙8s',
    screen: '6.59英寸 OLED',
    battery: '6500mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/s50/',
  ),
  Phone(
    brand: 'vivo',
    name: 'X Fold6',
    releaseDate: '2026-06',
    chipset: '天玑9500超能版',
    screen: '折叠屏 OLED',
    battery: '7000mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/xfold6/',
  ),
  Phone(
    brand: 'vivo',
    name: 'Y500',
    releaseDate: '2025-09',
    chipset: '天玑7300',
    screen: '6.67英寸 OLED',
    battery: '6000mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/y500/',
  ),

  // ---------- 荣耀 ----------
  Phone(
    brand: '荣耀',
    name: 'Magic8 Pro',
    releaseDate: '2026-03',
    chipset: '第五代骁龙8至尊版',
    screen: '6.71英寸 OLED',
    battery: '5900mAh',
    sourceUrl: 'https://www.honor.com/cn/products/magic8-pro/',
  ),
  Phone(
    brand: '荣耀',
    name: 'Magic V5',
    releaseDate: '2025-07',
    chipset: '骁龙8至尊版',
    screen: '7.95英寸 折叠屏 OLED',
    battery: '5820mAh',
    sourceUrl: 'https://www.honor.com/cn/products/magicv5/',
  ),
  Phone(
    brand: '荣耀',
    name: '500',
    releaseDate: '2025-11',
    chipset: '骁龙8 Gen2',
    screen: '6.7英寸 OLED',
    battery: '8000mAh',
    sourceUrl: 'https://www.honor.com/cn/products/500/',
  ),
  Phone(
    brand: '荣耀',
    name: '500 Pro',
    releaseDate: '2025-11',
    chipset: '骁龙8 Gen3',
    screen: '6.78英寸 OLED',
    battery: '6000mAh',
    sourceUrl: 'https://www.honor.com/cn/products/500pro/',
  ),
  Phone(
    brand: '荣耀',
    name: 'Magic8',
    releaseDate: '2025-10',
    chipset: '骁龙8 Gen3',
    screen: '6.78英寸 OLED',
    battery: '5600mAh',
    sourceUrl: 'https://www.honor.com/cn/products/magic8/',
  ),
  Phone(
    brand: '荣耀',
    name: 'GT Pro',
    releaseDate: '2025-09',
    chipset: '骁龙8 Gen3',
    screen: '6.78英寸 OLED',
    battery: '5800mAh',
    sourceUrl: 'https://www.honor.com/cn/products/gt-pro/',
  ),

  // ---------- 一加 ----------
  Phone(
    brand: '一加',
    name: '一加 15',
    releaseDate: '2025-12',
    chipset: '第五代骁龙8至尊版',
    screen: '6.82英寸 2K AMOLED',
    battery: '6000mAh',
    sourceUrl: 'https://www.oneplus.com/cn/15/',
  ),
  Phone(
    brand: '一加',
    name: 'Ace 6',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版',
    screen: '6.83英寸 1.5K OLED',
    battery: '7800mAh',
    sourceUrl: 'https://www.oneplus.com/cn/ace6/',
  ),

  // ---------- 三星 ----------
  Phone(
    brand: '三星',
    name: 'Galaxy S26 Ultra',
    releaseDate: '2026-03',
    chipset: '骁龙8至尊版Gen5',
    screen: '6.9英寸 Dynamic AMOLED 2X',
    battery: '5000mAh',
    sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s26-ultra/',
  ),
  Phone(
    brand: '三星',
    name: 'Galaxy S25 Ultra',
    releaseDate: '2025-02',
    chipset: '骁龙8至尊版',
    screen: '6.9英寸 Dynamic AMOLED 2X',
    battery: '5000mAh',
    sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s25-ultra/',
  ),
  Phone(
    brand: '三星',
    name: 'Galaxy S25 FE',
    releaseDate: '2025-09',
    chipset: '骁龙8 Gen3',
    screen: '6.7英寸 AMOLED',
    battery: '4500mAh',
    sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s25-fe/',
  ),

  // ---------- realme ----------
  Phone(
    brand: 'realme',
    name: 'GT8',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版',
    screen: '6.79英寸 2K AMOLED',
    battery: '7000mAh',
    sourceUrl: 'https://www.realme.com/cn/gt8/',
  ),
  Phone(
    brand: 'realme',
    name: 'GT8 Pro',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版Gen5',
    screen: '6.79英寸 2K AMOLED',
    battery: '7000mAh',
    sourceUrl: 'https://www.realme.com/cn/gt8pro/',
  ),

  // ---------- Redmi ----------
  Phone(
    brand: 'Redmi',
    name: 'K90',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版',
    screen: '6.59英寸 OLED',
    battery: '7100mAh',
    sourceUrl: 'https://www.mi.com/redmik90/',
  ),
  Phone(
    brand: 'Redmi',
    name: 'K90 Pro Max',
    releaseDate: '2025-10',
    chipset: '第五代骁龙8至尊版',
    screen: '6.9英寸 OLED',
    battery: '7560mAh',
    sourceUrl: 'https://www.mi.com/redmik90promax/',
  ),
  Phone(
    brand: 'Redmi',
    name: 'K90 Pro',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版',
    screen: '6.67英寸 OLED',
    battery: '6400mAh',
    sourceUrl: 'https://www.mi.com/redmik90pro/',
  ),

  // ---------- iQOO ----------
  Phone(
    brand: 'iQOO',
    name: '15',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版',
    screen: '6.78英寸 AMOLED',
    battery: '6000mAh',
    sourceUrl: 'https://www.iqoo.com/cn/phone-iqoo15/',
  ),
];

Map<String, List<Phone>> groupByBrand(List<Phone> phones) {
  final map = <String, List<Phone>>{};
  for (final p in phones) {
    map.putIfAbsent(p.brand, () => <Phone>[]).add(p);
  }
  return map;
}

// ============================================================
// 背景
// ============================================================

class GradientMeshBackground extends StatelessWidget {
  final Widget child;

  const GradientMeshBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(color: AppColors.bgBase),
        Positioned.fill(
          child: IgnorePointer(
            child: CustomPaint(painter: _GridPainter()),
          ),
        ),
        Positioned(
          top: -220,
          left: -140,
          child: _RadialGlow(
            size: 600,
            color: AppColors.primary,
            opacity: 0.18,
            stop: 0.6,
          ),
        ),
        Positioned(
          top: 60,
          right: -180,
          child: _RadialGlow(
            size: 560,
            color: AppColors.violet,
            opacity: 0.16,
            stop: 0.65,
          ),
        ),
        Positioned(
          bottom: -180,
          left: 60,
          child: _RadialGlow(
            size: 500,
            color: AppColors.accentOrange,
            opacity: 0.06,
            stop: 0.7,
          ),
        ),
        child,
      ],
    );
  }
}

class _RadialGlow extends StatelessWidget {
  final double size;
  final Color color;
  final double opacity;
  final double stop;

  const _RadialGlow({
    required this.size,
    required this.color,
    required this.opacity,
    required this.stop,
  });

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [color.withOpacity(opacity), Colors.transparent],
            stops: [0, stop],
          ),
        ),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.035)
      ..strokeWidth = 1;

    const gap = 24.0;
    for (double x = 0; x <= size.width; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ============================================================
// 液态玻璃卡片
// ============================================================

enum GlassLevel { low, medium, high }

class LiquidGlassCard extends StatefulWidget {
  final Widget child;
  final GlassLevel level;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry? padding;
  final double? borderRadius;

  const LiquidGlassCard({
    super.key,
    required this.child,
    this.level = GlassLevel.medium,
    this.onTap,
    this.padding,
    this.borderRadius,
  });

  @override
  State<LiquidGlassCard> createState() => _LiquidGlassCardState();
}

class _LiquidGlassCardState extends State<LiquidGlassCard> {
  bool _pressed = false;

  double get _blur {
    switch (widget.level) {
      case GlassLevel.low:
        return GlassTokens.blurLow;
      case GlassLevel.medium:
        return GlassTokens.blurMedium;
      case GlassLevel.high:
        return GlassTokens.blurHigh;
    }
  }

  Color get _fill {
    switch (widget.level) {
      case GlassLevel.low:
        return AppColors.glassFillLow;
      case GlassLevel.medium:
        return AppColors.glassFillMedium;
      case GlassLevel.high:
        return AppColors.glassFillHigh;
    }
  }

  Color get _strokeTop {
    switch (widget.level) {
      case GlassLevel.low:
        return const Color.fromRGBO(255, 255, 255, 0.24);
      case GlassLevel.medium:
        return const Color.fromRGBO(255, 255, 255, 0.28);
      case GlassLevel.high:
        return const Color.fromRGBO(255, 255, 255, 0.32);
    }
  }

  Color get _strokeBottom {
    switch (widget.level) {
      case GlassLevel.low:
        return const Color.fromRGBO(255, 255, 255, 0.04);
      case GlassLevel.medium:
        return const Color.fromRGBO(255, 255, 255, 0.06);
      case GlassLevel.high:
        return const Color.fromRGBO(255, 255, 255, 0.08);
    }
  }

  @override
  Widget build(BuildContext context) {
    final reduced = MediaQuery.maybeDisableAnimationsOf(context) ?? false;
    final radius = widget.borderRadius ?? AppRadius.lg;

    return GestureDetector(
      onTapDown: widget.onTap == null
          ? null
          : (_) => setState(() => _pressed = true),
      onTapUp: widget.onTap == null
          ? null
          : (_) {
              setState(() => _pressed = false);
              widget.onTap!();
            },
      onTapCancel: widget.onTap == null
          ? null
          : () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed && !reduced ? 0.985 : 1,
        duration: reduced ? Duration.zero : MotionTokens.press,
        curve: MotionTokens.curveStandard,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [_strokeTop, _strokeBottom],
            ),
            boxShadow: const [AppShadows.card],
          ),
          padding: const EdgeInsets.all(0.5),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(radius - 0.5),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: _blur, sigmaY: _blur),
              child: Container(
                padding: widget.padding ?? const EdgeInsets.all(AppSpacing.lg),
                decoration: BoxDecoration(
                  color: _fill,
                  borderRadius: BorderRadius.circular(radius - 0.5),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.center,
                    colors: [
                      Colors.white.withOpacity(0.08),
                      Colors.transparent,
                    ],
                  ),
                ),
                child: widget.child,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// 搜索框
// ============================================================

class GlassSearchBar extends StatelessWidget {
  final String hint;
  final VoidCallback? onTap;

  const GlassSearchBar({
    super.key,
    this.hint = '搜索品牌、型号或芯片',
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppRadius.pill),
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: GlassTokens.blurMedium,
            sigmaY: GlassTokens.blurMedium,
          ),
          child: Container(
            height: 52,
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
            decoration: BoxDecoration(
              color: AppColors.glassFillMedium,
              borderRadius: BorderRadius.circular(AppRadius.pill),
              border: Border.all(
                color: AppColors.glassStrokeTop,
                width: 0.8,
              ),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.search,
                  size: 20,
                  color: AppColors.textSecondary,
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: Text(
                    hint,
                    style: const TextStyle(
                      fontSize: 15,
                      height: 22 / 15,
                      color: AppColors.textOnGlass,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class GlassTextField extends StatelessWidget {
  final TextEditingController controller;
  final ValueChanged<String>? onChanged;
  final String hint;
  final VoidCallback? onClear;
  final bool showClear;

  const GlassTextField({
    super.key,
    required this.controller,
    this.onChanged,
    this.hint = '搜索品牌、型号或芯片',
    this.onClear,
    this.showClear = false,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppRadius.pill),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: GlassTokens.blurMedium,
          sigmaY: GlassTokens.blurMedium,
        ),
        child: Container(
          height: 52,
          padding: const EdgeInsets.symmetric(horizontal: 18),
          decoration: BoxDecoration(
            color: AppColors.glassFillMedium,
            borderRadius: BorderRadius.circular(AppRadius.pill),
            border: Border.all(
              color: AppColors.glassStrokeTop,
              width: 0.8,
            ),
          ),
          child: Row(
            children: [
              const Icon(
                Icons.search,
                size: 20,
                color: AppColors.textSecondary,
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: TextField(
                  controller: controller,
                  onChanged: onChanged,
                  cursorColor: AppColors.primary,
                  style: const TextStyle(
                    fontSize: 15,
                    height: 22 / 15,
                    color: AppColors.textOnGlass,
                  ),
                  decoration: InputDecoration(
                    isDense: true,
                    border: InputBorder.none,
                    hintText: hint,
                    hintStyle: const TextStyle(
                      fontSize: 15,
                      height: 22 / 15,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ),
              ),
              if (showClear)
                GestureDetector(
                  onTap: onClear,
                  behavior: HitTestBehavior.opaque,
                  child: Container(
                    width: 28,
                    height: 28,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.10),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.close_rounded,
                      size: 16,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// 心形收藏按钮
// ============================================================

class FavoriteButton extends StatelessWidget {
  final bool active;
  final VoidCallback onTap;

  const FavoriteButton({
    super.key,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 40,
        height: 40,
        child: Center(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 180),
            transitionBuilder: (child, animation) {
              return ScaleTransition(
                scale: animation,
                child: FadeTransition(opacity: animation, child: child),
              );
            },
            child: Icon(
              active ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              key: ValueKey<bool>(active),
              size: 22,
              color: active ? AppColors.error : AppColors.textTertiary,
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// 机型卡片
// ============================================================

class PhoneCard extends StatelessWidget {
  final Phone phone;
  final FavoritesController favorites;

  const PhoneCard({
    super.key,
    required this.phone,
    required this.favorites,
  });

  @override
  Widget build(BuildContext context) {
    return LiquidGlassCard(
      level: GlassLevel.medium,
      padding: const EdgeInsets.fromLTRB(16, 12, 10, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      phone.name,
                      style: const TextStyle(
                        fontSize: 17,
                        height: 24 / 17,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textOnGlass,
                        letterSpacing: 0,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Text(
                          phone.displayReleaseDate,
                          style: const TextStyle(
                            fontSize: 12,
                            height: 18 / 12,
                            color: AppColors.textSecondary,
                          ),
                        ),
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 6),
                          child: _Dot(),
                        ),
                        Flexible(
                          child: Text(
                            phone.chipset,
                            style: const TextStyle(
                              fontSize: 12,
                              height: 18 / 12,
                              color: AppColors.textSecondary,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              ListenableBuilder(
                listenable: favorites,
                builder: (context, _) {
                  final active = favorites.isFavorite(phone.id);
                  return FavoriteButton(
                    active: active,
                    onTap: () => favorites.toggle(phone.id),
                  );
                },
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: [
              _SpecChip(label: phone.screen),
              _SpecChip(label: phone.battery),
            ],
          ),
          const SizedBox(height: 12),
          _SourceRow(
            url: phone.sourceUrl,
            domain: phone.displayDomain,
            onTap: () {
              Clipboard.setData(ClipboardData(text: phone.sourceUrl));
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: const Text('来源链接已复制'),
                  behavior: SnackBarBehavior.floating,
                  backgroundColor: AppColors.surface2,
                  duration: const Duration(seconds: 2),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppRadius.md),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _Dot extends StatelessWidget {
  const _Dot();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 3,
      height: 3,
      decoration: const BoxDecoration(
        color: AppColors.textTertiary,
        shape: BoxShape.circle,
      ),
    );
  }
}

class _SpecChip extends StatelessWidget {
  final String label;

  const _SpecChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(AppRadius.pill),
        border: Border.all(
          color: Colors.white.withOpacity(0.06),
          width: 0.5,
        ),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 11,
          height: 16 / 11,
          fontWeight: FontWeight.w500,
          color: AppColors.textSecondary,
        ),
      ),
    );
  }
}

class _SourceRow extends StatelessWidget {
  final String url;
  final String domain;
  final VoidCallback onTap;

  const _SourceRow({
    required this.url,
    required this.domain,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            const Icon(
              Icons.link_rounded,
              size: 14,
              color: AppColors.primary,
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                domain,
                style: const TextStyle(
                  fontSize: 11,
                  height: 16 / 11,
                  fontWeight: FontWeight.w500,
                  color: AppColors.primary,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(width: 6),
            const Icon(
              Icons.copy_rounded,
              size: 12,
              color: AppColors.textTertiary,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// 首页
// ============================================================

class BrandHeader extends StatelessWidget {
  final String brand;
  final int count;

  const BrandHeader({
    super.key,
    required this.brand,
    required this.count,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.xl,
        AppSpacing.xxl,
        AppSpacing.xl,
        AppSpacing.md,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.baseline,
        textBaseline: TextBaseline.alphabetic,
        children: [
          ShaderMask(
            shaderCallback: (rect) => const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFFFFFFFF),
                Color(0xFF45D6FF),
                Color(0xFF9B7BFF),
              ],
              stops: [0.0, 0.4, 1.0],
            ).createShader(rect),
            blendMode: BlendMode.srcIn,
            child: Text(
              brand,
              style: const TextStyle(
                fontSize: 28,
                height: 36 / 28,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.4,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(AppRadius.pill),
              border: Border.all(
                color: Colors.white.withOpacity(0.08),
                width: 0.5,
              ),
            ),
            child: Text(
              '$count 款',
              style: const TextStyle(
                fontSize: 11,
                height: 16 / 11,
                fontWeight: FontWeight.w500,
                color: AppColors.textTertiary,
                letterSpacing: 0.2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final FavoritesController favorites;
  final VoidCallback onSearchTap;

  const HomePage({
    super.key,
    required this.favorites,
    required this.onSearchTap,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late final Map<String, List<Phone>> _grouped;

  @override
  void initState() {
    super.initState();
    _grouped = groupByBrand(allPhones);
  }

  @override
  Widget build(BuildContext context) {
    final brands = _grouped.keys.toList();

    return GradientMeshBackground(
      child: SafeArea(
        bottom: false,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(child: _buildHeader()),
            SliverList.builder(
              itemCount: brands.length,
              itemBuilder: (context, index) {
                final brand = brands[index];
                final phones = _grouped[brand]!;
                return _buildBrandSection(brand, phones);
              },
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 100)),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.xl,
        AppSpacing.lg,
        AppSpacing.xl,
        AppSpacing.xs,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: ShaderMask(
                  shaderCallback: (rect) => const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFFFFFFFF),
                      Color(0xFF45D6FF),
                      Color(0xFF9B7BFF),
                    ],
                    stops: [0.0, 0.5, 1.0],
                  ).createShader(rect),
                  blendMode: BlendMode.srcIn,
                  child: const Text(
                    '机鉴',
                    style: TextStyle(
                      fontSize: 36,
                      height: 44 / 36,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.6,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.08),
                    width: 0.6,
                  ),
                ),
                child: Text(
                  '${allPhones.length} 款机型',
                  style: const TextStyle(
                    fontSize: 12,
                    height: 16 / 12,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textSecondary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          const Text(
            '按品牌分类 · 数据来源：厂商公开规格页 · 点击来源可复制',
            style: TextStyle(
              fontSize: 12,
              height: 18 / 12,
              color: AppColors.textTertiary,
            ),
          ),
          const SizedBox(height: 16),
          GlassSearchBar(onTap: widget.onSearchTap),
        ],
      ),
    );
  }

  Widget _buildBrandSection(String brand, List<Phone> phones) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        BrandHeader(brand: brand, count: phones.length),
        ...phones.map(
          (phone) => Padding(
            padding: const EdgeInsets.fromLTRB(
              AppSpacing.xl,
              0,
              AppSpacing.xl,
              AppSpacing.md,
            ),
            child: PhoneCard(
              phone: phone,
              favorites: widget.favorites,
            ),
          ),
        ),
      ],
    );
  }
}

// ============================================================
// 搜索页
// ============================================================

class SearchPage extends StatefulWidget {
  final FavoritesController favorites;

  const SearchPage({super.key, required this.favorites});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final TextEditingController _controller = TextEditingController();
  String _query = '';

  List<Phone> get _results {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return allPhones;
    return allPhones.where((p) {
      return p.brand.toLowerCase().contains(q) ||
          p.name.toLowerCase().contains(q) ||
          p.chipset.toLowerCase().contains(q);
    }).toList();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final results = _results;

    return GradientMeshBackground(
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
              child: GlassTextField(
                controller: _controller,
                hint: '搜索品牌、型号或芯片',
                showClear: _query.isNotEmpty,
                onClear: () {
                  _controller.clear();
                  setState(() => _query = '');
                },
                onChanged: (v) => setState(() => _query = v),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Row(
                children: [
                  Text(
                    _query.trim().isEmpty ? '全部机型' : '搜索结果',
                    style: const TextStyle(
                      fontSize: 13,
                      height: 18 / 13,
                      fontWeight: FontWeight.w500,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '${results.length} 款',
                    style: const TextStyle(
                      fontSize: 12,
                      height: 18 / 12,
                      color: AppColors.textTertiary,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: results.isEmpty
                  ? const _SearchEmptyState()
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(20, 4, 20, 100),
                      itemCount: results.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (_, i) => PhoneCard(
                        phone: results[i],
                        favorites: widget.favorites,
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SearchEmptyState extends StatelessWidget {
  const _SearchEmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(
              Icons.search_off_rounded,
              size: 64,
              color: AppColors.textTertiary,
            ),
            SizedBox(height: 20),
            Text(
              '未找到相关机型',
              style: TextStyle(
                fontSize: 17,
                height: 24 / 17,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary,
              ),
            ),
            SizedBox(height: 8),
            Text(
              '尝试更换品牌名、型号关键词或芯片名称',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
                height: 18 / 12,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// 收藏页
// ============================================================

class FavoritesPage extends StatelessWidget {
  final FavoritesController favorites;

  const FavoritesPage({super.key, required this.favorites});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: favorites,
      builder: (context, _) {
        final list =
            allPhones.where((p) => favorites.isFavorite(p.id)).toList();

        return GradientMeshBackground(
          child: SafeArea(
            child: CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      textBaseline: TextBaseline.alphabetic,
                      children: [
                        const Text(
                          '收藏',
                          style: TextStyle(
                            fontSize: 28,
                            height: 36 / 28,
                            fontWeight: FontWeight.w700,
                            letterSpacing: -0.4,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          '${list.length} 款',
                          style: const TextStyle(
                            fontSize: 12,
                            height: 18 / 12,
                            color: AppColors.textTertiary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (list.isEmpty)
                  const SliverFillRemaining(
                    hasScrollBody: false,
                    child: _FavoritesEmptyState(),
                  )
                else
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
                    sliver: SliverList.separated(
                      itemCount: list.length,
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: 12),
                      itemBuilder: (_, i) => PhoneCard(
                        phone: list[i],
                        favorites: favorites,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _FavoritesEmptyState extends StatelessWidget {
  const _FavoritesEmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(
              Icons.favorite_border_rounded,
              size: 64,
              color: AppColors.textTertiary,
            ),
            SizedBox(height: 20),
            Text(
              '暂无收藏',
              style: TextStyle(
                fontSize: 17,
                height: 24 / 17,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary,
              ),
            ),
            SizedBox(height: 8),
            Text(
              '在首页或搜索页点击机型卡片右上角的心形图标，即可收藏',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
                height: 18 / 12,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// 品牌页（本次新增）
// ============================================================

class BrandsPage extends StatefulWidget {
  final FavoritesController favorites;

  const BrandsPage({super.key, required this.favorites});

  @override
  State<BrandsPage> createState() => _BrandsPageState();
}

class _BrandsPageState extends State<BrandsPage> {
  late final Map<String, List<Phone>> _grouped;
  String? _selectedBrand;

  @override
  void initState() {
    super.initState();
    _grouped = groupByBrand(allPhones);
  }

  @override
  Widget build(BuildContext context) {
    if (_selectedBrand != null) {
      return _buildBrandDetail(_selectedBrand!);
    }
    return _buildBrandGrid();
  }

  // ---------- 品牌网格 ----------
  Widget _buildBrandGrid() {
    final brands = _grouped.keys.toList();

    return GradientMeshBackground(
      child: SafeArea(
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    ShaderMask(
                      shaderCallback: (rect) => const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color(0xFFFFFFFF),
                          Color(0xFF45D6FF),
                          Color(0xFF9B7BFF),
                        ],
                        stops: [0.0, 0.5, 1.0],
                      ).createShader(rect),
                      blendMode: BlendMode.srcIn,
                      child: const Text(
                        '品牌',
                        style: TextStyle(
                          fontSize: 28,
                          height: 36 / 28,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.4,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      '${brands.length} 个品牌',
                      style: const TextStyle(
                        fontSize: 12,
                        height: 18 / 12,
                        color: AppColors.textTertiary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                child: Text(
                  '点击品牌卡片，查看该品牌全部机型',
                  style: TextStyle(
                    fontSize: 12,
                    height: 18 / 12,
                    color: AppColors.textTertiary.withOpacity(0.9),
                  ),
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 100),
              sliver: SliverGrid(
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.35,
                ),
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final brand = brands[index];
                    return _buildBrandCard(brand, _grouped[brand]!);
                  },
                  childCount: brands.length,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBrandCard(String brand, List<Phone> phones) {
    return LiquidGlassCard(
      level: GlassLevel.medium,
      borderRadius: AppRadius.lg,
      padding: EdgeInsets.zero,
      onTap: () => setState(() => _selectedBrand = brand),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppRadius.lg - 1),
        child: Stack(
          children: [
            // 背景首字母水印
            Positioned(
              right: -12,
              bottom: -28,
              child: Text(
                brand.substring(0, 1),
                style: TextStyle(
                  fontSize: 96,
                  height: 1,
                  fontWeight: FontWeight.w900,
                  color: Colors.white.withOpacity(0.05),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    brand,
                    style: const TextStyle(
                      fontSize: 20,
                      height: 28 / 20,
                      fontWeight: FontWeight.w700,
                      letterSpacing: -0.2,
                      color: AppColors.textOnGlass,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primary.withOpacity(0.6),
                              blurRadius: 6,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        '${phones.length} 款机型',
                        style: const TextStyle(
                          fontSize: 12,
                          height: 16 / 12,
                          fontWeight: FontWeight.w500,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      const Spacer(),
                      const Icon(
                        Icons.chevron_right_rounded,
                        size: 18,
                        color: AppColors.textTertiary,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------- 品牌详情 ----------
  Widget _buildBrandDetail(String brand) {
    final phones = _grouped[brand]!;

    return GradientMeshBackground(
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 12, 20, 8),
              child: Row(
                children: [
                  SizedBox(
                    width: 44,
                    height: 44,
                    child: IconButton(
                      onPressed: () =>
                          setState(() => _selectedBrand = null),
                      icon: const Icon(
                        Icons.arrow_back_ios_new_rounded,
                        size: 20,
                        color: AppColors.textPrimary,
                      ),
                      tooltip: '返回品牌列表',
                    ),
                  ),
                  const SizedBox(width: 4),
                  Expanded(
                    child: ShaderMask(
                      shaderCallback: (rect) => const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color(0xFFFFFFFF),
                          Color(0xFF45D6FF),
                          Color(0xFF9B7BFF),
                        ],
                        stops: [0.0, 0.5, 1.0],
                      ).createShader(rect),
                      blendMode: BlendMode.srcIn,
                      child: Text(
                        brand,
                        style: const TextStyle(
                          fontSize: 26,
                          height: 34 / 26,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.4,
                          color: Colors.white,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(AppRadius.pill),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.08),
                        width: 0.6,
                      ),
                    ),
                    child: Text(
                      '${phones.length} 款',
                      style: const TextStyle(
                        fontSize: 12,
                        height: 16 / 12,
                        fontWeight: FontWeight.w500,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
                physics: const AlwaysScrollableScrollPhysics(),
                itemCount: phones.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (_, i) => PhoneCard(
                  phone: phones[i],
                  favorites: widget.favorites,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// 我的页面（本次新增）
// ============================================================

class ProfilePage extends StatelessWidget {
  final FavoritesController favorites;

  const ProfilePage({super.key, required this.favorites});

  @override
  Widget build(BuildContext context) {
    return GradientMeshBackground(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
          children: [
            // 头像 + 昵称
            LiquidGlassCard(
              level: GlassLevel.medium,
              padding: const EdgeInsets.all(18),
              child: Row(
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          AppColors.primary.withOpacity(0.28),
                          AppColors.violet.withOpacity(0.28),
                        ],
                      ),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.16),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primary.withOpacity(0.20),
                          blurRadius: 22,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.person_rounded,
                      size: 32,
                      color: AppColors.textOnGlass,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '数码爱好者',
                          style: TextStyle(
                            fontSize: 18,
                            height: 26 / 18,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textOnGlass,
                            letterSpacing: -0.2,
                          ),
                        ),
                        const SizedBox(height: 4),
                        ListenableBuilder(
                          listenable: favorites,
                          builder: (context, _) {
                            return Text(
                              '已收藏 ${favorites.count} 款机型',
                              style: const TextStyle(
                                fontSize: 12,
                                height: 16 / 12,
                                color: AppColors.textSecondary,
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 免责声明
            LiquidGlassCard(
              level: GlassLevel.medium,
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: const [
                      Icon(
                        Icons.shield_outlined,
                        size: 16,
                        color: AppColors.primary,
                      ),
                      SizedBox(width: 8),
                      Text(
                        '免责声明',
                        style: TextStyle(
                          fontSize: 14,
                          height: 20 / 14,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textOnGlass,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    '本应用数据来源于各品牌官网及公开网络，仅供学习交流使用，如有误差欢迎纠错。',
                    style: TextStyle(
                      fontSize: 13,
                      height: 20 / 13,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 设置列表
            LiquidGlassCard(
              level: GlassLevel.medium,
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  _SettingsItem(
                    icon: Icons.privacy_tip_outlined,
                    label: '隐私政策',
                    onTap: () => _showPrivacyDialog(context),
                  ),
                  Container(
                    height: 1,
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    color: Colors.white.withOpacity(0.06),
                  ),
                  _SettingsItem(
                    icon: Icons.info_outline_rounded,
                    label: '关于机鉴',
                    onTap: () => _showAboutDialog(context),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // 版本号
            const Center(
              child: Text(
                '当前版本：v1.0.1',
                style: TextStyle(
                  fontSize: 12,
                  height: 18 / 12,
                  color: AppColors.textTertiary,
                  letterSpacing: 0.2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showPrivacyDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => _buildGlassDialog(
        context: ctx,
        title: '隐私政策',
        content: const Text(
          '本应用为纯本地工具，不收集您的任何个人身份信息。\n\n'
          '1. 收藏数据仅保存在您的设备本地（SharedPreferences），不会上传服务器。\n'
          '2. 应用不申请位置、相机、麦克风、通讯录等敏感权限。\n'
          '3. 机型数据来源于各品牌官网与公开信息，仅作查询与学习参考。\n\n'
          '如需清除收藏数据，卸载应用即可。',
          style: TextStyle(
            fontSize: 13,
            height: 20 / 13,
            color: AppColors.textSecondary,
          ),
        ),
      ),
    );
  }

  void _showAboutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => _buildGlassDialog(
        context: ctx,
        title: '关于机鉴',
        content: const Text(
          '机鉴 · 手机图鉴\n\n'
          '一个专注于「可核实机型资料」的本地资料库。收录近 10 年主流品牌机型，'
          '覆盖芯片、屏幕、电池、发布时间等结构化字段，并标注来源链接供随时核验。\n\n'
          '不宣称全量覆盖，不对缺失字段做推测填充。数据持续更新，以来源链接指向的原始页面为准。\n\n'
          '版本：v1.0.1',
          style: TextStyle(
            fontSize: 13,
            height: 20 / 13,
            color: AppColors.textSecondary,
          ),
        ),
      ),
    );
  }

  Widget _buildGlassDialog({
    required BuildContext context,
    required String title,
    required Widget content,
  }) {
    return AlertDialog(
      backgroundColor: AppColors.surface2,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        side: BorderSide(
          color: Colors.white.withOpacity(0.08),
          width: 0.8,
        ),
      ),
      title: Text(
        title,
        style: const TextStyle(
          fontSize: 17,
          height: 24 / 17,
          fontWeight: FontWeight.w700,
          color: AppColors.textPrimary,
        ),
      ),
      content: SingleChildScrollView(child: content),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text(
            '我知道了',
            style: TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }
}

class _SettingsItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _SettingsItem({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppRadius.lg),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 16,
        ),
        child: Row(
          children: [
            Icon(icon, size: 20, color: AppColors.primary),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  fontSize: 15,
                  height: 22 / 15,
                  fontWeight: FontWeight.w500,
                  color: AppColors.textOnGlass,
                ),
              ),
            ),
            const Icon(
              Icons.chevron_right_rounded,
              size: 20,
              color: AppColors.textTertiary,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// 底部导航
// ============================================================

class GlassBottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const GlassBottomNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  static const _items = [
    _NavItem(icon: Icons.home_outlined, selectedIcon: Icons.home, label: '首页'),
    _NavItem(
      icon: Icons.grid_view_outlined,
      selectedIcon: Icons.grid_view,
      label: '品牌',
    ),
    _NavItem(
      icon: Icons.search_outlined,
      selectedIcon: Icons.search,
      label: '搜索',
    ),
    _NavItem(
      icon: Icons.bookmark_border,
      selectedIcon: Icons.bookmark,
      label: '收藏',
    ),
    _NavItem(
      icon: Icons.person_outline,
      selectedIcon: Icons.person,
      label: '我的',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: GlassTokens.blurHigh,
          sigmaY: GlassTokens.blurHigh,
        ),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.glassFillHigh,
            border: Border(
              top: BorderSide(
                color: AppColors.glassStrokeTop,
                width: 0.6,
              ),
            ),
          ),
          child: SafeArea(
            top: false,
            child: SizedBox(
              height: 56,
              child: Row(
                children: List.generate(_items.length, (index) {
                  final selected = index == currentIndex;
                  final item = _items[index];
                  return Expanded(
                    child: InkWell(
                      onTap: () => onTap(index),
                      splashColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            selected ? item.selectedIcon : item.icon,
                            size: 24,
                            color: selected
                                ? AppColors.primary
                                : AppColors.textTertiary,
                          ),
                          const SizedBox(height: 2),
                          Text(
                            item.label,
                            style: TextStyle(
                              fontSize: 11,
                              height: 16 / 11,
                              fontWeight: FontWeight.w500,
                              color: selected
                                  ? AppColors.primary
                                  : AppColors.textTertiary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final IconData selectedIcon;
  final String label;

  const _NavItem({
    required this.icon,
    required this.selectedIcon,
    required this.label,
  });
}