import 'package:flutter/material.dart';
import 'home_page.dart'; // 复用浅色公用组件

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
      children: [
        // 顶部：头像与昵称（纯白卡片）
        LiquidGlassCard(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF9B7BFF), // 浅紫
                      Color(0xFF45D6FF), // 浅蓝
                    ],
                  ),
                  border: Border.all(color: Colors.white, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF9B7BFF).withValues(alpha: 0.3),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.person_rounded,
                  size: 36,
                  color: Colors.white,
                ),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '数码爱好者',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textPrimary,
                        letterSpacing: -0.5,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      '专注探索科技与参数',
                      style: TextStyle(
                        fontSize: 13,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 16),

        // 免责声明
        LiquidGlassCard(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.shield_outlined, size: 18, color: AppColors.primary),
                  const SizedBox(width: 8),
                  const Text(
                    '免责声明',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Text(
                '本应用数据来源于各品牌官网及公开网络，仅供学习交流使用，如有误差欢迎纠错。',
                style: TextStyle(
                  fontSize: 13,
                  height: 1.5,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 16),

        // 设置列表（纯白背景）
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 15,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.privacy_tip_outlined, color: AppColors.primary, size: 22),
                title: const Text('隐私政策', style: TextStyle(color: AppColors.textPrimary, fontSize: 15)),
                trailing: const Icon(Icons.chevron_right, color: AppColors.textSecondary),
                onTap: () => _showGlassDialog(
                  context,
                  '隐私政策',
                  '本应用为纯本地工具，不收集您的任何个人身份信息。\n\n'
                  '1. 收藏数据仅保存在您的设备本地（SharedPreferences），不会上传服务器。\n'
                  '2. 应用不申请位置、相机、麦克风、通讯录等敏感权限。\n'
                  '3. 机型数据来源于各品牌官网与公开信息，仅作查询与学习参考。\n\n'
                  '如需清除收藏数据，卸载应用即可。',
                ),
              ),
              const Divider(height: 1, color: Color(0xFFF0F0F0), indent: 16, endIndent: 16),
              ListTile(
                leading: const Icon(Icons.info_outline_rounded, color: AppColors.primary, size: 22),
                title: const Text('关于机鉴', style: TextStyle(color: AppColors.textPrimary, fontSize: 15)),
                trailing: const Icon(Icons.chevron_right, color: AppColors.textSecondary),
                onTap: () => _showGlassDialog(
                  context,
                  '关于机鉴',
                  '机鉴 · 手机图鉴\n\n'
                  '一个专注于「可核实机型资料」的本地资料库。收录主流品牌机型，'
                  '覆盖芯片、屏幕、电池、发布时间等结构化字段。\n\n'
                  '数据持续更新，以来源链接指向的原始页面为准。',
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 32),

        // 底部版本号
        const Center(
          child: Text(
            '当前版本：v1.0.1',
            style: TextStyle(
              fontSize: 12,
              color: AppColors.textSecondary,
              letterSpacing: 0.5,
            ),
          ),
        ),
      ],
    );
  }

  // 浅色高级弹窗
  void _showGlassDialog(BuildContext context, String title, String content) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent, 
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
        ),
        content: SingleChildScrollView(
          child: Text(
            content,
            style: const TextStyle(fontSize: 14, height: 1.6, color: AppColors.textSecondary),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('我知道了', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600, fontSize: 16)),
          ),
        ],
      ),
    );
  }
}