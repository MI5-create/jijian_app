import 'package:flutter/material.dart';
import '../models/phone_model.dart';
import '../controllers/favorites_controller.dart';
// 引入首页的公用浅色组件和详情页
import 'home_page.dart';
import 'phone_detail_page.dart';

class FavoritesPage extends StatelessWidget {
  final FavoritesController favorites;
  const FavoritesPage({super.key, required this.favorites});

  @override
  Widget build(BuildContext context) {
    // 监听收藏状态的变化，实现实时更新
    return ListenableBuilder(
      listenable: favorites,
      builder: (context, child) {
        // 从全部手机中筛选出已被收藏的机型
        final list = allPhones.where((p) => favorites.isFavorite(p.id)).toList();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 顶部标题与数量统计
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  const Text(
                    '收藏',
                    style: TextStyle(
                      fontSize: 28, 
                      fontWeight: FontWeight.w800, 
                      color: AppColors.textPrimary, // 深色标题
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    '${list.length} 款机型',
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                  ),
                ],
              ),
            ),

            // 列表或空状态
            Expanded(
              child: list.isEmpty
                  ? const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.favorite_border, size: 64, color: AppColors.textTertiary),
                          SizedBox(height: 16),
                          Text(
                            '暂无收藏',
                            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                          ),
                          SizedBox(height: 8),
                          Text(
                            '在首页或搜索页点击心形图标即可收藏',
                            style: TextStyle(fontSize: 13, color: AppColors.textSecondary),
                          ),
                        ],
                      ),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
                      physics: const AlwaysScrollableScrollPhysics(),
                      itemCount: list.length,
                      separatorBuilder: (context, index) => const SizedBox(height: 12),
                      itemBuilder: (context, i) {
                        final p = list[i];
                        return LiquidGlassCard(
                          // 点击跳转详情页
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => PhoneDetailPage(phone: p)),
                            );
                          },
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          '${p.brand} ${p.name}', 
                                          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          '${p.displayReleaseDate} · ${p.chipset}', 
                                          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                                        ),
                                      ],
                                    ),
                                  ),
                                  // 收藏页里的心形必然是实心的，点击直接取消收藏
                                  FavoriteButton(
                                    active: true,
                                    onTap: () => favorites.toggle(p.id),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        );
      },
    );
  }
}