import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import '../models/phone_model.dart';
import '../controllers/favorites_controller.dart';
import 'phone_detail_page.dart'; // 引入详情页

// ============================================================
// ==== 以下为全局公用 UI 组件（浅色版）====
// ============================================================

class AppColors {
  AppColors._();
  static const bgBase = Color(0xFFF2F5FA); // 浅灰蓝背景
  static const surfaceWhite = Colors.white; // 纯白卡片
  static const glassFill = Color.fromRGBO(255, 255, 255, 0.75); // 浅色磨砂
  static const glassStrokeTop = Color.fromRGBO(255, 255, 255, 0.9);
  
  static const primary = Color(0xFF007AFF); // 蓝色强调
  static const violet = Color(0xFF9B7BFF); 
  static const error = Color(0xFFFF3B30); // 红色心形
  
  static const textPrimary = Color(0xFF1A1C1E); // 深黑主文字
  static const textSecondary = Color(0xFF8E8E93); // 灰色副文字
  static const textTertiary = Color(0xFFC7C7CC);
}

class LiquidGlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double borderRadius;
  final VoidCallback? onTap;

  const LiquidGlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderRadius = 20.0,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Widget content = Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        // 浅色高级阴影
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: AppColors.glassFill,
              border: Border.all(color: AppColors.glassStrokeTop, width: 1),
              borderRadius: BorderRadius.circular(borderRadius),
            ),
            child: child,
          ),
        ),
      ),
    );

    if (onTap != null) {
      return GestureDetector(onTap: onTap, child: content);
    }
    return content;
  }
}

class FavoriteButton extends StatelessWidget {
  final bool active;
  final VoidCallback onTap;
  const FavoriteButton({super.key, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 40,
        height: 40,
        child: Center(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 180),
            transitionBuilder: (child, animation) => ScaleTransition(scale: animation, child: child),
            child: Icon(
              active ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              key: ValueKey<bool>(active),
              size: 24,
              color: active ? AppColors.error : AppColors.textTertiary,
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// ==== 首页页面本体 ====
// ============================================================

class HomePage extends StatefulWidget {
  final FavoritesController favorites;
  const HomePage({super.key, required this.favorites});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late final Map<String, List<Phone>> _grouped;

  @override
  void initState() {
    super.initState();
    _grouped = <String, List<Phone>>{};
    for (final p in allPhones) {
      _grouped.putIfAbsent(p.brand, () => []).add(p);
    }
  }

  @override
  Widget build(BuildContext context) {
    final brands = _grouped.keys.toList();

    return ListView.builder(
      padding: const EdgeInsets.only(top: 20, bottom: 100),
      itemCount: brands.length,
      itemBuilder: (context, index) {
        final brand = brands[index];
        final phones = _grouped[brand] ?? [];
        
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 品牌大标题
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
              child: Text(
                brand,
                style: const TextStyle(
                  fontSize: 22, 
                  fontWeight: FontWeight.bold, 
                  color: AppColors.textPrimary,
                  letterSpacing: -0.5,
                ),
              ),
            ),
            // 该品牌下的手机列表
            ...phones.map((p) => Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
              child: LiquidGlassCard(
                // 点击跳转详情页
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => PhoneDetailPage(phone: p)),
                  );
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                p.name, 
                                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: AppColors.textPrimary)
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${p.displayReleaseDate} · ${p.chipset}', 
                                style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)
                              ),
                            ],
                          ),
                        ),
                        // 心形收藏按钮
                        ListenableBuilder(
                          listenable: widget.favorites,
                          builder: (context, child) => FavoriteButton(
                            active: widget.favorites.isFavorite(p.id),
                            onTap: () => widget.favorites.toggle(p.id),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _buildChip(p.screen),
                        const SizedBox(width: 8),
                        _buildChip(p.battery),
                      ],
                    ),
                  ],
                ),
              ),
            )),
          ],
        );
      },
    );
  }

  // 浅色参数小标签
  Widget _buildChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
    );
  }
}