import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/phone_model.dart';

class PhoneDetailPage extends StatelessWidget {
  final Phone phone;
  const PhoneDetailPage({super.key, required this.phone});

  // 改成 get 属性，完美避开 const 构造函数冲突
  BoxShadow get _softShadow => BoxShadow(
        color: Colors.black.withValues(alpha: 0.05),
        blurRadius: 15,
        offset: const Offset(0, 5),
      );

  Future<void> _launchUrl(BuildContext context) async {
    final Uri url = Uri.parse(phone.sourceUrl);
    try {
      if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('无法打开该链接')),
          );
        }
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('打开链接失败: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F5FA),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black87, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          '在售手机图鉴 · 当前热门旗舰',
          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Colors.black87, letterSpacing: 0.5),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 1. 头部信息区
            Text(
              '${phone.brand} · 数据来自官网',
              style: const TextStyle(color: Colors.blue, fontSize: 14, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            Text(
              phone.name,
              style: const TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.w800,
                color: Colors.black87,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const Text(
                  '即将上市',
                  style: TextStyle(color: Colors.blue, fontSize: 18, fontWeight: FontWeight.w600),
                ),
                Text(
                  '发布于 ${phone.releaseDate}',
                  style: const TextStyle(color: Colors.grey, fontSize: 13),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // 2. 核心参数网格区
            Row(
              children: [
                Expanded(child: _buildCoreParamCard('处理器', phone.chipset)),
                const SizedBox(width: 16),
                Expanded(child: _buildCoreParamCard('电池', phone.battery)),
              ],
            ),
            const SizedBox(height: 24),

            // 3. 标签与按钮区
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _buildTag('旗舰'),
                _buildTag('影像'),
                _buildTag('高性能'),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: Container(
                    height: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      gradient: const LinearGradient(
                        colors: [Color(0xFF9B7BFF), Color(0xFF45D6FF)],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF9B7BFF).withValues(alpha: 0.3),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(25),
                        onTap: () {}, 
                        child: const Center(
                          child: Text(
                            '+ 加入对比',
                            style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 20),
                GestureDetector(
                  onTap: () => _launchUrl(context),
                  child: const Row(
                    children: [
                      Text(
                        '品牌官网',
                        style: TextStyle(color: Colors.black87, fontSize: 15, fontWeight: FontWeight.w500),
                      ),
                      SizedBox(width: 2),
                      Icon(Icons.arrow_outward, size: 16, color: Colors.black87),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),

            // 4. 详细参数列表区
            Row(
              children: [
                Container(
                  width: 4,
                  height: 18,
                  decoration: BoxDecoration(
                    color: const Color(0xFF9B7BFF),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 8),
                const Text(
                  '完整参数',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [_softShadow],
              ),
              child: Column(
                children: [
                  _buildDetailRow('屏幕显示', phone.screen, showDivider: true),
                  _buildDetailRow('电池容量', phone.battery, showDivider: true),
                  _buildDetailRow('核心处理器', phone.chipset, showDivider: true),
                  _buildDetailRow('发布时间', phone.releaseDate, showDivider: false),
                ],
              ),
            ),
            
            const SizedBox(height: 40),

            // 5. 底部免责声明
            const Center(
              child: Text(
                '数据采集于各品牌官网，仅供参考',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 核心参数小卡片
  Widget _buildCoreParamCard(String label, String value) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [_softShadow],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Colors.grey, fontSize: 13)),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(color: Colors.black87, fontSize: 17, fontWeight: FontWeight.bold),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  // 浅蓝色标签
  Widget _buildTag(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.blue.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: const TextStyle(color: Colors.blue, fontSize: 13, fontWeight: FontWeight.w500),
      ),
    );
  }

  // 详细参数行
  Widget _buildDetailRow(String label, String value, {bool showDivider = true}) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: 90,
                child: Text(
                  label,
                  style: const TextStyle(color: Colors.grey, fontSize: 14),
                ),
              ),
              Expanded(
                child: Text(
                  value,
                  style: const TextStyle(color: Colors.black87, fontSize: 15, fontWeight: FontWeight.w500),
                  textAlign: TextAlign.right,
                ),
              ),
            ],
          ),
        ),
        if (showDivider)
          const Divider(height: 1, color: Color(0xFFF0F0F0), thickness: 1),
      ],
    );
  }
}