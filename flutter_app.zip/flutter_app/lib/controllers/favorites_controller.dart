import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FavoritesController extends ChangeNotifier {
  // 在手机本地保存数据的“钥匙”
  static const _prefsKey = 'favorite_phone_ids';

  // 内存中的收藏集合（用于 UI 实时显示）
  final Set<String> _ids = <String>{};

  Set<String> get ids => Set.unmodifiable(_ids);
  int get count => _ids.length;
  bool isFavorite(String id) => _ids.contains(id);

  /// 1. 启动时加载数据
  /// 这个方法会在 App 刚打开时（在 main.dart 中）被调用一次，
  /// 负责把本地硬盘里的数据读出来，恢复上次的收藏状态。
  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      // 从手机本地取出列表，如果没有存过，默认给个空列表
      final stored = prefs.getStringList(_prefsKey) ?? const <String>[];
      
      _ids
        ..clear()
        ..addAll(stored);
      
      // 通知 UI 刷新
      notifyListeners();
    } catch (e) {
      debugPrint('本地存储读取失败: $e');
    }
  }

  /// 2. 点击收藏/取消收藏
  Future<void> toggle(String id) async {
    // 第一步：先更新内存，让 UI 瞬间变色，毫无延迟
    if (_ids.contains(id)) {
      _ids.remove(id);
    } else {
      _ids.add(id);
    }
    notifyListeners();

    // 第二步：立刻将最新状态写入手机本地硬盘
    try {
      final prefs = await SharedPreferences.getInstance();
      // 转成 List 排序后保存
      final sortedList = _ids.toList()..sort();
      // 持久化写入！关掉 App 再打开数据依然存在
      await prefs.setStringList(_prefsKey, sortedList);
    } catch (e) {
      debugPrint('本地存储写入失败: $e');
    }
  }
}