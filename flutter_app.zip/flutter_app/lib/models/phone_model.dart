class Phone {
  final String brand;
  final String name;
  final String releaseDate;
  final String chipset;
  final String screen;
  final String battery;
  final String sourceUrl;

  const Phone({
    required this.brand,
    required this.name,
    required this.releaseDate,
    required this.chipset,
    required this.screen,
    required this.battery,
    required this.sourceUrl,
  });

  /// 唯一标识：品牌::型号。用于本地收藏的持久化存储。
  String get id => '$brand::$name';

  /// 格式化日期：2025-11 -> 2025 年 11 月
  String get displayReleaseDate {
    final parts = releaseDate.split('-');
    if (parts.length == 2) {
      final year = parts[0];
      final month = int.tryParse(parts[1]);
      if (month != null) return '$year 年 $month 月';
    }
    // 如果本身已经是 '2024年11月' 这种格式，直接返回
    return releaseDate;
  }

  /// 获取来源链接的域名，用于展示
  String get displayDomain {
    try {
      return Uri.parse(sourceUrl).host;
    } catch (_) {
      return sourceUrl;
    }
  }
}

/// 全部机型数据（截图旧数据 + 160款新数据，共约 200 款）
final List<Phone> allPhones = const [
  // ==========================================
  // ---------- 华为 ----------
  // ==========================================
  Phone(brand: '华为', name: 'Mate 70', releaseDate: '2024年11月', chipset: '麒麟9010', screen: '6.7英寸 OLED', battery: '5300mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate70/'),
  Phone(brand: '华为', name: 'Mate 70 Pro', releaseDate: '2024年11月', chipset: '麒麟9020', screen: '6.85英寸 OLED', battery: '5700mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate70pro/'),
  Phone(brand: '华为', name: 'Mate 70 Pro+', releaseDate: '2024年11月', chipset: '麒麟9020', screen: '6.85英寸 OLED', battery: '5700mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate70proplus/'),
  Phone(brand: '华为', name: 'Mate 70 RS 非凡大师', releaseDate: '2024年11月', chipset: '麒麟9020', screen: '6.85英寸 OLED', battery: '5700mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate70rs/'),
  Phone(brand: '华为', name: 'Mate 70 Air', releaseDate: '2025年11月', chipset: '麒麟9020', screen: '6.7英寸 OLED', battery: '5800mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate70air/'),
  Phone(brand: '华为', name: 'Mate X6', releaseDate: '2024年11月', chipset: '麒麟9020', screen: '折叠屏 OLED', battery: '5700mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/matex6/'),
  Phone(brand: '华为', name: 'Pura 70', releaseDate: '2024年4月', chipset: '麒麟9000S', screen: '6.7英寸 OLED', battery: '5050mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/pura70/'),
  Phone(brand: '华为', name: 'Pura 70 Pro', releaseDate: '2024年4月', chipset: '麒麟9010', screen: '6.8英寸 OLED', battery: '5050mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/pura70pro/'),
  Phone(brand: '华为', name: 'Pura 70 Pro+', releaseDate: '2024年4月', chipset: '麒麟9010', screen: '6.8英寸 OLED', battery: '5100mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/pura70proplus/'),
  Phone(brand: '华为', name: 'Pura 70 Ultra', releaseDate: '2024年4月', chipset: '麒麟9010', screen: '6.8英寸 OLED', battery: '5200mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/pura70ultra/'),
  Phone(brand: '华为', name: 'Pura 70 Art', releaseDate: '2024年6月', chipset: '麒麟9010', screen: '6.8英寸 OLED', battery: '5200mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/pura70art/'),
  Phone(brand: '华为', name: 'Mate 60 Pro', releaseDate: '2023年8月', chipset: '麒麟9000S', screen: '6.82英寸 OLED', battery: '5000mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate60pro/'),
  Phone(brand: '华为', name: 'nova 12 Ultra', releaseDate: '2024年12月', chipset: '麒麟9000SL', screen: '6.7英寸 OLED', battery: '4600mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/nova12ultra/'),
  Phone(brand: '华为', name: 'nova 12 Pro', releaseDate: '2024年12月', chipset: '麒麟8000', screen: '6.7英寸 OLED', battery: '4600mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/nova12pro/'),
  Phone(brand: '华为', name: 'nova 15', releaseDate: '2025年12月', chipset: '麒麟8020', screen: '6.7英寸 OLED', battery: '6000mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/nova15/'),
  Phone(brand: '华为', name: 'nova 15 Pro', releaseDate: '2025年12月', chipset: '麒麟9010S', screen: '6.84英寸 OLED', battery: '5000mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/nova15pro/'),
  Phone(brand: '华为', name: 'nova 15 Ultra', releaseDate: '2025年12月', chipset: '麒麟9010S', screen: '6.84英寸 OLED', battery: '5000mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/nova15ultra/'),
  Phone(brand: '华为', name: 'nova Flip', releaseDate: '2024年8月', chipset: '骁龙8 Gen2', screen: '6.9英寸 折叠屏', battery: '4300mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/novaflip/'),
  Phone(brand: '华为', name: 'nova 13', releaseDate: '2024年10月', chipset: '骁龙6 Gen1', screen: '6.7英寸 OLED', battery: '5000mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/nova13/'),
  Phone(brand: '华为', name: 'nova 13 Pro', releaseDate: '2024年10月', chipset: '骁龙7 Gen3', screen: '6.78英寸 OLED', battery: '5100mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/nova13pro/'),
  Phone(brand: '华为', name: 'nova 14', releaseDate: '2025年5月', chipset: '骁龙6 Gen1', screen: '6.7英寸 OLED', battery: '5500mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/nova14/'),
  Phone(brand: '华为', name: 'nova 14 Pro', releaseDate: '2025年5月', chipset: '骁龙7 Gen3', screen: '6.78英寸 OLED', battery: '5500mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/nova14pro/'),
  Phone(brand: '华为', name: 'nova 14 Ultra', releaseDate: '2025年5月', chipset: '骁龙8 Gen3', screen: '6.78英寸 2K OLED', battery: '5500mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/nova14ultra/'),
  Phone(brand: '华为', name: 'Pocket 2', releaseDate: '2023年12月', chipset: '骁龙8 Gen1', screen: '折叠屏 OLED', battery: '4500mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/pocket2/'),
  Phone(brand: '华为', name: 'Mate XT', releaseDate: '2024年9月', chipset: '麒麟9000S', screen: '折叠屏 OLED', battery: '5600mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/matext/'),
  Phone(brand: '华为', name: '畅享70 Pro', releaseDate: '2023年10月', chipset: '骁龙6 Gen1', screen: '6.7英寸 OLED', battery: '5000mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/changxiang70pro/'),
  // 截图旧版数据补全
  Phone(brand: '华为', name: 'Mate 80', releaseDate: '2025-11', chipset: '麒麟 9020', screen: '6.75英寸 OLED', battery: '5750mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80/'),
  Phone(brand: '华为', name: 'Mate 80 Pro', releaseDate: '2025-11', chipset: '麒麟 9030', screen: '6.75英寸 OLED', battery: '5750mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80pro/'),
  Phone(brand: '华为', name: 'Mate 80 Pro Max', releaseDate: '2025-11', chipset: '麒麟 9030 Pro', screen: '6.9英寸 OLED', battery: '6000mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80promax/'),
  Phone(brand: '华为', name: 'Mate 80 RS 非凡大师', releaseDate: '2025-11', chipset: '麒麟 9030 Pro', screen: '6.9英寸 OLED', battery: '6000mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80rs/'),
  Phone(brand: '华为', name: 'Pura 80', releaseDate: '2025-06', chipset: '麒麟 9010S', screen: '6.6英寸 OLED', battery: '5600mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/pura80/'),
  Phone(brand: '华为', name: 'Pura 80 Pro', releaseDate: '2025-06', chipset: '麒麟 9020', screen: '6.8英寸 OLED', battery: '5700mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/pura80pro/'),
  Phone(brand: '华为', name: 'Pura 80 Ultra', releaseDate: '2025-06', chipset: '麒麟 9020', screen: '6.8英寸 OLED', battery: '5700mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/pura80ultra/'),
  Phone(brand: '华为', name: 'Mate X7', releaseDate: '2025-11', chipset: '麒麟 9020', screen: '折叠屏 OLED', battery: '5750mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/matex7/'),
  Phone(brand: '华为', name: 'Mate XT 非凡大师', releaseDate: '2025-04', chipset: '麒麟9020', screen: '三折叠屏 OLED', battery: '6000mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/matext/'),

  // ==========================================
  // ---------- 苹果 ----------
  // ==========================================
  Phone(brand: '苹果', name: 'iPhone 16', releaseDate: '2024年9月', chipset: 'A18', screen: '6.1英寸 OLED', battery: '3561mAh', sourceUrl: 'https://www.apple.com/iphone-16/'),
  Phone(brand: '苹果', name: 'iPhone 16 Plus', releaseDate: '2024年9月', chipset: 'A18', screen: '6.7英寸 OLED', battery: '4000mAh', sourceUrl: 'https://www.apple.com/iphone-16-plus/'),
  Phone(brand: '苹果', name: 'iPhone 16 Pro', releaseDate: '2024年9月', chipset: 'A18 Pro', screen: '6.3英寸 OLED', battery: '3274mAh', sourceUrl: 'https://www.apple.com/iphone-16-pro/'),
  Phone(brand: '苹果', name: 'iPhone 16 Pro Max', releaseDate: '2024年9月', chipset: 'A18 Pro', screen: '6.9英寸 OLED', battery: '4685mAh', sourceUrl: 'https://www.apple.com/iphone-16-pro-max/'),
  Phone(brand: '苹果', name: 'iPhone 15', releaseDate: '2023年9月', chipset: 'A16', screen: '6.1英寸 OLED', battery: '3349mAh', sourceUrl: 'https://www.apple.com/iphone-15/'),
  Phone(brand: '苹果', name: 'iPhone 15 Plus', releaseDate: '2023年9月', chipset: 'A16', screen: '6.7英寸 OLED', battery: '4000mAh', sourceUrl: 'https://www.apple.com/iphone-15-plus/'),
  Phone(brand: '苹果', name: 'iPhone 15 Pro', releaseDate: '2023年9月', chipset: 'A17 Pro', screen: '6.1英寸 OLED', battery: '3274mAh', sourceUrl: 'https://www.apple.com/iphone-15-pro/'),
  Phone(brand: '苹果', name: 'iPhone 15 Pro Max', releaseDate: '2023年9月', chipset: 'A17 Pro', screen: '6.7英寸 OLED', battery: '4422mAh', sourceUrl: 'https://www.apple.com/iphone-15-pro-max/'),
  Phone(brand: '苹果', name: 'iPhone 14', releaseDate: '2022年9月', chipset: 'A15', screen: '6.1英寸 OLED', battery: '3279mAh', sourceUrl: 'https://www.apple.com/iphone-14/'),
  Phone(brand: '苹果', name: 'iPhone 14 Plus', releaseDate: '2022年9月', chipset: 'A15', screen: '6.7英寸 OLED', battery: '4325mAh', sourceUrl: 'https://www.apple.com/iphone-14-plus/'),
  Phone(brand: '苹果', name: 'iPhone 14 Pro', releaseDate: '2022年9月', chipset: 'A16', screen: '6.1英寸 OLED', battery: '3200mAh', sourceUrl: 'https://www.apple.com/iphone-14-pro/'),
  Phone(brand: '苹果', name: 'iPhone 14 Pro Max', releaseDate: '2022年9月', chipset: 'A16', screen: '6.7英寸 OLED', battery: '4323mAh', sourceUrl: 'https://www.apple.com/iphone-14-pro-max/'),
  // 截图旧版数据
  Phone(brand: '苹果', name: 'iPhone 17', releaseDate: '2025-09', chipset: 'A19', screen: '6.3英寸 OLED', battery: '3692mAh', sourceUrl: 'https://www.apple.com/iphone-17/'),
  Phone(brand: '苹果', name: 'iPhone 17 Air', releaseDate: '2025-09', chipset: 'A19 Pro', screen: '6.5英寸 OLED', battery: '3149mAh', sourceUrl: 'https://www.apple.com/iphone-air/'),
  Phone(brand: '苹果', name: 'iPhone 17 Pro', releaseDate: '2025-09', chipset: 'A19 Pro', screen: '6.3英寸 OLED', battery: '3988mAh', sourceUrl: 'https://www.apple.com/iphone-17-pro/'),
  Phone(brand: '苹果', name: 'iPhone 17 Pro Max', releaseDate: '2025-09', chipset: 'A19 Pro', screen: '6.9英寸 OLED', battery: '4832mAh', sourceUrl: 'https://www.apple.com/iphone-17-pro-max/'),

  // ==========================================
  // ---------- 小米 ----------
  // ==========================================
  Phone(brand: '小米', name: '小米13', releaseDate: '2023年1月', chipset: '骁龙8 Gen2', screen: '6.36英寸 AMOLED', battery: '4500mAh', sourceUrl: 'https://www.mi.com/xiaomi13/'),
  Phone(brand: '小米', name: '小米13 Pro', releaseDate: '2023年1月', chipset: '骁龙8 Gen2', screen: '6.73英寸 AMOLED', battery: '4820mAh', sourceUrl: 'https://www.mi.com/xiaomi13pro/'),
  Phone(brand: '小米', name: '小米13 Ultra', releaseDate: '2023年4月', chipset: '骁龙8 Gen2', screen: '6.73英寸 AMOLED', battery: '5000mAh', sourceUrl: 'https://www.mi.com/xiaomi13ultra/'),
  Phone(brand: '小米', name: '小米14', releaseDate: '2024年2月', chipset: '骁龙8 Gen3', screen: '6.36英寸 OLED', battery: '4610mAh', sourceUrl: 'https://www.mi.com/xiaomi14/'),
  Phone(brand: '小米', name: '小米14 Pro', releaseDate: '2024年2月', chipset: '骁龙8 Gen3', screen: '6.73英寸 OLED', battery: '4880mAh', sourceUrl: 'https://www.mi.com/xiaomi14pro/'),
  Phone(brand: '小米', name: '小米14 Ultra', releaseDate: '2024年2月', chipset: '骁龙8 Gen3', screen: '6.73英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.mi.com/xiaomi14ultra/'),
  Phone(brand: '小米', name: '小米15', releaseDate: '2024年10月', chipset: '骁龙8至尊版', screen: '6.36英寸 OLED', battery: '5400mAh', sourceUrl: 'https://www.mi.com/xiaomi15/'),
  Phone(brand: '小米', name: '小米15 Pro', releaseDate: '2024年10月', chipset: '骁龙8至尊版', screen: '6.73英寸 2K OLED', battery: '5500mAh', sourceUrl: 'https://www.mi.com/xiaomi15pro/'),
  Phone(brand: '小米', name: '小米15 Ultra', releaseDate: '2025年3月', chipset: '骁龙8至尊版', screen: '6.73英寸 OLED', battery: '6000mAh', sourceUrl: 'https://www.mi.com/xiaomi15ultra/'),
  Phone(brand: '小米', name: '小米MIX Fold 4', releaseDate: '2025年7月', chipset: '骁龙8 Gen3', screen: '8.01英寸 折叠屏', battery: '5100mAh', sourceUrl: 'https://www.mi.com/mixfold4/'),
  Phone(brand: '小米', name: '小米Civi 4 Pro', releaseDate: '2024年3月', chipset: '骁龙8 Gen3', screen: '6.55英寸 AMOLED', battery: '4700mAh', sourceUrl: 'https://www.mi.com/xiaomiciv4pro/'),
  Phone(brand: '小米', name: '小米MIX Flip', releaseDate: '2024年7月', chipset: '骁龙8 Gen3', screen: '折叠屏 OLED', battery: '4780mAh', sourceUrl: 'https://www.mi.com/mixflip/'),
  // 截图旧版数据
  Phone(brand: '小米', name: 'Xiaomi 17', releaseDate: '2025-09', chipset: '第五代骁龙8至尊版', screen: '6.3英寸 OLED', battery: '7000mAh', sourceUrl: 'https://www.mi.com/xiaomi17/'),
  Phone(brand: '小米', name: 'Xiaomi 17 Pro', releaseDate: '2025-09', chipset: '第五代骁龙8至尊版', screen: '6.3英寸 OLED（含背屏）', battery: '6300mAh', sourceUrl: 'https://www.mi.com/xiaomi17pro/'),
  Phone(brand: '小米', name: 'Xiaomi 17 Pro Max', releaseDate: '2025-09', chipset: '第五代骁龙8至尊版', screen: '6.9英寸 OLED', battery: '7500mAh', sourceUrl: 'https://www.mi.com/xiaomi17promax/'),
  Phone(brand: '小米', name: 'Xiaomi 17 Ultra', releaseDate: '2026-03', chipset: '骁龙8至尊版', screen: '6.73英寸 OLED', battery: '5500mAh', sourceUrl: 'https://www.mi.com/xiaomi17ultra/'),

  // ==========================================
  // ---------- Redmi ----------
  // ==========================================
  Phone(brand: 'Redmi', name: 'K70', releaseDate: '2023年11月', chipset: '骁龙8 Gen2', screen: '6.67英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.mi.com/redmik70/'),
  Phone(brand: 'Redmi', name: 'K70 Pro', releaseDate: '2023年11月', chipset: '骁龙8 Gen3', screen: '6.67英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.mi.com/redmik70pro/'),
  Phone(brand: 'Redmi', name: 'K70 至尊版', releaseDate: '2024年7月', chipset: '天玑9300+', screen: '6.67英寸 OLED', battery: '5500mAh', sourceUrl: 'https://www.mi.com/redmik70ultra/'),
  Phone(brand: 'Redmi', name: 'K80', releaseDate: '2025年6月', chipset: '骁龙8 Gen3', screen: '6.67英寸 2K OLED', battery: '6550mAh', sourceUrl: 'https://www.mi.com/redmik80/'),
  Phone(brand: 'Redmi', name: 'K80 至尊版', releaseDate: '2025年6月', chipset: '天玑9400+', screen: '6.83英寸 144Hz OLED', battery: '7410mAh', sourceUrl: 'https://www.mi.com/redmik80ultra/'),
  Phone(brand: 'Redmi', name: 'Turbo 4 Pro', releaseDate: '2025年4月', chipset: '第三代骁龙8s', screen: '6.83英寸 1.5K OLED', battery: '7550mAh', sourceUrl: 'https://www.mi.com/redmiturbo4pro/'),
  Phone(brand: 'Redmi', name: 'Turbo 3', releaseDate: '2024年9月', chipset: '第三代骁龙8', screen: '6.67英寸 1.5K OLED', battery: '5500mAh', sourceUrl: 'https://www.mi.com/redmiturbo3/'),
  Phone(brand: 'Redmi', name: 'Note 13 Pro+', releaseDate: '2023年10月', chipset: '天玑7200 Ultra', screen: '6.67英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.mi.com/redminote13proplus/'),
  Phone(brand: 'Redmi', name: 'Note 14', releaseDate: '2024年9月', chipset: '天玑7020', screen: '6.67英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.mi.com/redminote14/'),
  Phone(brand: 'Redmi', name: 'Note 14 Pro', releaseDate: '2024年9月', chipset: '天玑7200 Ultra', screen: '6.67英寸 1.5K OLED', battery: '5110mAh', sourceUrl: 'https://www.mi.com/redminote14pro/'),
  Phone(brand: 'Redmi', name: 'Note 14 Pro+', releaseDate: '2024年9月', chipset: '天玑9200+', screen: '6.67英寸 2K OLED', battery: '5110mAh', sourceUrl: 'https://www.mi.com/redminote14proplus/'),
  Phone(brand: 'Redmi', name: '14R 5G', releaseDate: '2024年9月', chipset: '天玑7020', screen: '6.74英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.mi.com/redmi14r5g/'),
  // 截图旧版数据
  Phone(brand: 'Redmi', name: 'K90', releaseDate: '2025-10', chipset: '骁龙8至尊版', screen: '6.59英寸 OLED', battery: '7100mAh', sourceUrl: 'https://www.mi.com/redmik90/'),
  Phone(brand: 'Redmi', name: 'K90 Pro Max', releaseDate: '2025-10', chipset: '第五代骁龙8至尊版', screen: '6.9英寸 OLED', battery: '7560mAh', sourceUrl: 'https://www.mi.com/redmik90promax/'),
  Phone(brand: 'Redmi', name: 'K90 Pro', releaseDate: '2025-10', chipset: '骁龙8至尊版', screen: '6.67英寸 OLED', battery: '6400mAh', sourceUrl: 'https://www.mi.com/redmik90pro/'),

  // ==========================================
  // ---------- OPPO ----------
  // ==========================================
  Phone(brand: 'OPPO', name: 'Find X8', releaseDate: '2025年3月', chipset: '天玑9400', screen: '6.59英寸 OLED', battery: '5700mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-x8/'),
  Phone(brand: 'OPPO', name: 'Find X8 Pro', releaseDate: '2025年3月', chipset: '骁龙8至尊版', screen: '6.78英寸 2K OLED', battery: '5900mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-x8-pro/'),
  Phone(brand: 'OPPO', name: 'Find X7', releaseDate: '2024年1月', chipset: '天玑9300', screen: '6.78英寸 AMOLED', battery: '5000mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-x7/'),
  Phone(brand: 'OPPO', name: 'Find X7 Ultra', releaseDate: '2024年4月', chipset: '骁龙8 Gen3', screen: '6.82英寸 2K AMOLED', battery: '5000mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-x7-ultra/'),
  Phone(brand: 'OPPO', name: 'Find X6', releaseDate: '2023年3月', chipset: '骁龙8 Gen2', screen: '6.74英寸 AMOLED', battery: '5000mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-x6/'),
  Phone(brand: 'OPPO', name: 'Find X6 Pro', releaseDate: '2023年3月', chipset: '骁龙8 Gen2', screen: '6.82英寸 2K AMOLED', battery: '5000mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-x6-pro/'),
  Phone(brand: 'OPPO', name: 'Find N3', releaseDate: '2023年11月', chipset: '骁龙8 Gen2', screen: '折叠屏 AMOLED', battery: '4805mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-n3/'),
  Phone(brand: 'OPPO', name: 'Reno 12', releaseDate: '2025年5月', chipset: '天玑8450', screen: '6.67英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.oppo.com/cn/phones/reno12/'),
  Phone(brand: 'OPPO', name: 'Reno 12 Pro', releaseDate: '2024年5月', chipset: '天玑9200+ 星速版', screen: '6.7英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.oppo.com/cn/phones/reno12pro/'),
  Phone(brand: 'OPPO', name: 'Reno 13', releaseDate: '2025年9月', chipset: '天玑8450', screen: '6.67英寸 OLED', battery: '5500mAh', sourceUrl: 'https://www.oppo.com/cn/phones/reno13/'),
  Phone(brand: 'OPPO', name: 'Reno 13 Pro', releaseDate: '2024年11月', chipset: '天玑8450', screen: '6.78英寸 OLED', battery: '5500mAh', sourceUrl: 'https://www.oppo.com/cn/phones/reno13pro/'),
  Phone(brand: 'OPPO', name: 'K13 Turbo', releaseDate: '2025年9月', chipset: '骁龙7 Gen3', screen: '6.78英寸 OLED', battery: '7000mAh', sourceUrl: 'https://www.oppo.com/cn/phones/k13turbo/'),
  Phone(brand: 'OPPO', name: 'K12', releaseDate: '2024年7月', chipset: '骁龙6 Gen1', screen: '6.67英寸 OLED', battery: '6000mAh', sourceUrl: 'https://www.oppo.com/cn/phones/k12/'),
  Phone(brand: 'OPPO', name: 'K12 Plus', releaseDate: '2024年7月', chipset: '骁龙7 Gen3', screen: '6.78英寸 OLED', battery: '6000mAh', sourceUrl: 'https://www.oppo.com/cn/phones/k12plus/'),
  Phone(brand: 'OPPO', name: 'K12x', releaseDate: '2024年9月', chipset: '骁龙6 Gen1', screen: '6.67英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.oppo.com/cn/phones/k12x/'),
  Phone(brand: 'OPPO', name: 'A5 5G', releaseDate: '2025年3月', chipset: '骁龙6 Gen1', screen: '6.7英寸 OLED', battery: '6500mAh', sourceUrl: 'https://www.oppo.com/cn/phones/a5-5g/'),
  Phone(brand: 'OPPO', name: 'A3 Pro', releaseDate: '2024年9月', chipset: '天玑7050', screen: '6.7英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.oppo.com/cn/phones/a3pro/'),
  // 截图旧版数据
  Phone(brand: 'OPPO', name: 'Find X9 Ultra', releaseDate: '2026-04', chipset: '第五代骁龙8至尊版', screen: '6.82英寸 2K AMOLED', battery: '7050mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-x9-ultra/'),
  Phone(brand: 'OPPO', name: 'Find X9 Pro', releaseDate: '2025-10', chipset: '天玑9400+', screen: '6.78英寸 AMOLED', battery: '5900mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-x9-pro/'),
  Phone(brand: 'OPPO', name: 'Find X8 Ultra', releaseDate: '2025-04', chipset: '骁龙8至尊版', screen: '6.82英寸 2K AMOLED', battery: '6100mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-x8-ultra/'),
  Phone(brand: 'OPPO', name: 'Reno 15', releaseDate: '2025-08', chipset: '天玑7300', screen: '6.67英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.oppo.com/cn/phones/reno15/'),
  Phone(brand: 'OPPO', name: 'Reno 15 Pro', releaseDate: '2025-08', chipset: '天玑9300+', screen: '6.78英寸 OLED', battery: '5500mAh', sourceUrl: 'https://www.oppo.com/cn/phones/reno15pro/'),
  Phone(brand: 'OPPO', name: 'Find N5', releaseDate: '2025-10', chipset: '骁龙8至尊版', screen: '折叠屏 AMOLED', battery: '5500mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-n5/'),

  // ==========================================
  // ---------- vivo ----------
  // ==========================================
  Phone(brand: 'vivo', name: 'X100', releaseDate: '2024年3月', chipset: '天玑9300', screen: '6.78英寸 AMOLED', battery: '5000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x100/'),
  Phone(brand: 'vivo', name: 'X100 Pro', releaseDate: '2024年3月', chipset: '天玑9300+', screen: '6.78英寸 2K AMOLED', battery: '5400mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x100pro/'),
  Phone(brand: 'vivo', name: 'X100 Ultra', releaseDate: '2024年5月', chipset: '骁龙8 Gen3', screen: '6.78英寸 2K AMOLED', battery: '5500mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x100ultra/'),
  Phone(brand: 'vivo', name: 'X100s', releaseDate: '2024年5月', chipset: '天玑9300+', screen: '6.78英寸 OLED', battery: '5100mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x100s/'),
  Phone(brand: 'vivo', name: 'X100s Pro', releaseDate: '2024年5月', chipset: '天玑9300+', screen: '6.78英寸 2K AMOLED', battery: '5400mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x100spro/'),
  Phone(brand: 'vivo', name: 'X200', releaseDate: '2025年4月', chipset: '天玑9400', screen: '6.67英寸 AMOLED', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x200/'),
  Phone(brand: 'vivo', name: 'X200 Pro', releaseDate: '2025年4月', chipset: '天玑9400', screen: '6.78英寸 2K AMOLED', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x200pro/'),
  Phone(brand: 'vivo', name: 'X200 Pro mini', releaseDate: '2025年4月', chipset: '天玑9400', screen: '6.31英寸 OLED', battery: '5700mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x200promini/'),
  Phone(brand: 'vivo', name: 'X Fold5', releaseDate: '2025年6月', chipset: '第三代骁龙8', screen: '8.03英寸 折叠屏', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/xfold5/'),
  Phone(brand: 'vivo', name: 'X Fold3', releaseDate: '2024年3月', chipset: '第二代骁龙8', screen: '8.03英寸 折叠屏', battery: '5500mAh', sourceUrl: 'https://www.vivo.com/cn/phones/xfold3/'),
  Phone(brand: 'vivo', name: 'X Fold3 Pro', releaseDate: '2024年3月', chipset: '第二代骁龙8', screen: '8.03英寸 折叠屏', battery: '5500mAh', sourceUrl: 'https://www.vivo.com/cn/phones/xfold3pro/'),
  Phone(brand: 'vivo', name: 'S19', releaseDate: '2024年5月', chipset: '天玑9300+', screen: '6.78英寸 AMOLED', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/s19/'),
  Phone(brand: 'vivo', name: 'S19 Pro', releaseDate: '2024年5月', chipset: '天玑9300+', screen: '6.78英寸 2K AMOLED', battery: '5800mAh', sourceUrl: 'https://www.vivo.com/cn/phones/s19pro/'),
  Phone(brand: 'vivo', name: 'S20', releaseDate: '2024年11月', chipset: '第三代骁龙7', screen: '6.67英寸 AMOLED', battery: '6500mAh', sourceUrl: 'https://www.vivo.com/cn/phones/s20/'),
  Phone(brand: 'vivo', name: 'S20 Pro', releaseDate: '2024年11月', chipset: '天玑9300+', screen: '6.78英寸 2K AMOLED', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/s20pro/'),
  Phone(brand: 'vivo', name: 'Y300', releaseDate: '2025年5月', chipset: '天玑6300', screen: '6.67英寸 OLED', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/y300/'),
  Phone(brand: 'vivo', name: 'Y200', releaseDate: '2024年', chipset: '骁龙6 Gen1', screen: '6.64英寸 OLED', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/y200/'),
  Phone(brand: 'vivo', name: 'Y300 Pro', releaseDate: '2024年', chipset: '天玑7050', screen: '6.67英寸 OLED', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/y300pro/'),
  // 截图旧版数据
  Phone(brand: 'vivo', name: 'X300 Ultra', releaseDate: '2026-03', chipset: '第五代骁龙8至尊版', screen: '6.82英寸 2K OLED', battery: '6600mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x300-ultra/'),
  Phone(brand: 'vivo', name: 'X300 Pro', releaseDate: '2025-10', chipset: '天玑9500', screen: '6.78英寸 OLED', battery: '6510mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x300-pro/'),
  Phone(brand: 'vivo', name: 'X300', releaseDate: '2025-10', chipset: '天玑9500', screen: '6.31英寸 OLED', battery: '6040mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x300/'),
  Phone(brand: 'vivo', name: 'X200 Ultra', releaseDate: '2025-04', chipset: '骁龙8至尊版', screen: '6.82英寸 2K OLED', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x200-ultra/'),
  Phone(brand: 'vivo', name: 'X200s', releaseDate: '2025-07', chipset: '天玑9400+', screen: '6.78英寸 OLED', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x200s/'),
  Phone(brand: 'vivo', name: 'S30', releaseDate: '2025-05', chipset: '天玑9300+', screen: '6.67英寸 OLED', battery: '5800mAh', sourceUrl: 'https://www.vivo.com/cn/phones/s30/'),
  Phone(brand: 'vivo', name: 'S50', releaseDate: '2025-12', chipset: '第三代骁龙8s', screen: '6.59英寸 OLED', battery: '6500mAh', sourceUrl: 'https://www.vivo.com/cn/phones/s50/'),
  Phone(brand: 'vivo', name: 'X Fold6', releaseDate: '2026-06', chipset: '天玑9500超能版', screen: '折叠屏 OLED', battery: '7000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/xfold6/'),
  Phone(brand: 'vivo', name: 'Y500', releaseDate: '2025-09', chipset: '天玑7300', screen: '6.67英寸 OLED', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/y500/'),

  // ==========================================
  // ---------- iQOO ----------
  // ==========================================
  Phone(brand: 'iQOO', name: '12', releaseDate: '2023年12月', chipset: '骁龙8 Gen3', screen: '6.78英寸 AMOLED', battery: '5000mAh', sourceUrl: 'https://www.iqoo.com/cn/phone-iqoo12/'),
  Phone(brand: 'iQOO', name: '13', releaseDate: '2024年10月', chipset: '骁龙8至尊版', screen: '6.82英寸 AMOLED', battery: '6000mAh', sourceUrl: 'https://www.iqoo.com/cn/phone-iqoo13/'),
  Phone(brand: 'iQOO', name: 'Z10 Turbo+', releaseDate: '2025年8月', chipset: '天玑9400++', screen: '6.78英寸 144Hz OLED', battery: '8000mAh', sourceUrl: 'https://www.iqoo.com/cn/phone-z10turboplus/'),
  Phone(brand: 'iQOO', name: 'Neo9', releaseDate: '2023年12月', chipset: '骁龙8 Gen2', screen: '6.78英寸 AMOLED', battery: '5160mAh', sourceUrl: 'https://www.iqoo.com/cn/phone-neo9/'),
  Phone(brand: 'iQOO', name: 'Z9', releaseDate: '2024年9月', chipset: '第三代骁龙7+', screen: '6.78英寸 AMOLED', battery: '6000mAh', sourceUrl: 'https://www.iqoo.com/cn/phone-z9/'),
  Phone(brand: 'iQOO', name: 'Z9 Turbo', releaseDate: '2024年9月', chipset: '第三代骁龙8', screen: '6.78英寸 144Hz AMOLED', battery: '6000mAh', sourceUrl: 'https://www.iqoo.com/cn/phone-z9turbo/'),
  Phone(brand: 'iQOO', name: 'Z9 Turbo+', releaseDate: '2024年12月', chipset: '天玑9300+', screen: '6.78英寸 144Hz OLED', battery: '6400mAh', sourceUrl: 'https://www.iqoo.com/cn/phone-z9turboplus/'),
  Phone(brand: 'iQOO', name: 'Neo9s Pro', releaseDate: '2024年9月', chipset: '骁龙8 Gen2', screen: '6.78英寸 AMOLED', battery: '5500mAh', sourceUrl: 'https://www.iqoo.com/cn/phone-neo9spro/'),
  Phone(brand: 'iQOO', name: 'Neo9s Pro+', releaseDate: '2024年9月', chipset: '骁龙8 Gen3', screen: '6.78英寸 2K AMOLED', battery: '5500mAh', sourceUrl: 'https://www.iqoo.com/cn/phone-neo9sproplus/'),
  Phone(brand: 'iQOO', name: 'Neo10', releaseDate: '2024年12月', chipset: '骁龙8 Gen3', screen: '6.78英寸 2K AMOLED', battery: '6000mAh', sourceUrl: 'https://www.iqoo.com/cn/phone-neo10/'),
  Phone(brand: 'iQOO', name: 'Neo10 Pro', releaseDate: '2024年12月', chipset: '天玑9400', screen: '6.78英寸 2K AMOLED', battery: '6000mAh', sourceUrl: 'https://www.iqoo.com/cn/phone-neo10pro/'),
  // 截图旧版数据
  Phone(brand: 'iQOO', name: '15', releaseDate: '2025-10', chipset: '骁龙8至尊版', screen: '6.78英寸 AMOLED', battery: '6000mAh', sourceUrl: 'https://www.iqoo.com/cn/phone-iqoo15/'),

  // ==========================================
  // ---------- 荣耀 ----------
  // ==========================================
  Phone(brand: '荣耀', name: 'Magic6', releaseDate: '2024年1月', chipset: '骁龙8 Gen3', screen: '6.78英寸 OLED', battery: '5450mAh', sourceUrl: 'https://www.honor.com/cn/products/magic6/'),
  Phone(brand: '荣耀', name: 'Magic6 Pro', releaseDate: '2024年1月', chipset: '骁龙8 Gen3', screen: '6.81英寸 OLED', battery: '5600mAh', sourceUrl: 'https://www.honor.com/cn/products/magic6pro/'),
  Phone(brand: '荣耀', name: 'Magic6 RSR', releaseDate: '2024年6月', chipset: '骁龙8 Gen3', screen: '6.81英寸 OLED', battery: '5600mAh', sourceUrl: 'https://www.honor.com/cn/products/magic6rsr/'),
  Phone(brand: '荣耀', name: 'Magic V3', releaseDate: '2024年7月', chipset: '骁龙8 Gen3', screen: '折叠屏 OLED', battery: '5150mAh', sourceUrl: 'https://www.honor.com/cn/products/magicv3/'),
  Phone(brand: '荣耀', name: '200', releaseDate: '2024年5月', chipset: '骁龙8s Gen3', screen: '6.7英寸 OLED', battery: '5200mAh', sourceUrl: 'https://www.honor.com/cn/products/200/'),
  Phone(brand: '荣耀', name: '200 Pro', releaseDate: '2024年5月', chipset: '骁龙8 Gen3', screen: '6.78英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.honor.com/cn/products/200pro/'),
  Phone(brand: '荣耀', name: 'Magic5', releaseDate: '2023年3月', chipset: '骁龙8 Gen2', screen: '6.73英寸 AMOLED', battery: '5100mAh', sourceUrl: 'https://www.honor.com/cn/products/magic5/'),
  Phone(brand: '荣耀', name: 'Magic5 Pro', releaseDate: '2023年3月', chipset: '骁龙8 Gen2', screen: '6.81英寸 2K AMOLED', battery: '5600mAh', sourceUrl: 'https://www.honor.com/cn/products/magic5pro/'),
  Phone(brand: '荣耀', name: 'Magic V2', releaseDate: '2023年7月', chipset: '骁龙8 Gen2', screen: '折叠屏 AMOLED', battery: '5000mAh', sourceUrl: 'https://www.honor.com/cn/products/magicv2/'),
  Phone(brand: '荣耀', name: 'Magic 7', releaseDate: '2024年10月', chipset: '骁龙8 Gen3', screen: '6.39英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.honor.com/cn/products/magic7/'),
  Phone(brand: '荣耀', name: 'Magic 7 Pro', releaseDate: '2025年1月', chipset: '骁龙8至尊版', screen: '6.85英寸 2K OLED', battery: '6000mAh', sourceUrl: 'https://www.honor.com/cn/products/magic7pro/'),
  Phone(brand: '荣耀', name: 'Magic V Flip', releaseDate: '2024年', chipset: '骁龙8 Gen3', screen: '折叠屏 OLED', battery: '4700mAh', sourceUrl: 'https://www.honor.com/cn/products/magicvflip/'),
  Phone(brand: '荣耀', name: '300', releaseDate: '2024年', chipset: '骁龙8s Gen3', screen: '6.7英寸 OLED', battery: '5200mAh', sourceUrl: 'https://www.honor.com/cn/products/300/'),
  Phone(brand: '荣耀', name: '300 Pro', releaseDate: '2024年', chipset: '骁龙8 Gen3', screen: '6.78英寸 2K OLED', battery: '5400mAh', sourceUrl: 'https://www.honor.com/cn/products/300pro/'),
  Phone(brand: '荣耀', name: '300 Ultra', releaseDate: '2024年', chipset: '骁龙8 Gen3', screen: '6.78英寸 2K OLED', battery: '5400mAh', sourceUrl: 'https://www.honor.com/cn/products/300ultra/'),
  Phone(brand: '荣耀', name: 'X50 GT', releaseDate: '2024年', chipset: '骁龙8 Gen2', screen: '6.78英寸 AMOLED', battery: '5500mAh', sourceUrl: 'https://www.honor.com/cn/products/x50gt/'),
  // 截图旧版数据
  Phone(brand: '荣耀', name: 'Magic8 Pro', releaseDate: '2026-03', chipset: '第五代骁龙8至尊版', screen: '6.71英寸 OLED', battery: '5900mAh', sourceUrl: 'https://www.honor.com/cn/products/magic8-pro/'),
  Phone(brand: '荣耀', name: 'Magic V5', releaseDate: '2025-07', chipset: '骁龙8至尊版', screen: '7.95英寸 折叠屏 OLED', battery: '5820mAh', sourceUrl: 'https://www.honor.com/cn/products/magicv5/'),
  Phone(brand: '荣耀', name: '500', releaseDate: '2025-11', chipset: '骁龙8 Gen2', screen: '6.7英寸 OLED', battery: '8000mAh', sourceUrl: 'https://www.honor.com/cn/products/500/'),
  Phone(brand: '荣耀', name: '500 Pro', releaseDate: '2025-11', chipset: '骁龙8 Gen3', screen: '6.78英寸 OLED', battery: '6000mAh', sourceUrl: 'https://www.honor.com/cn/products/500pro/'),
  Phone(brand: '荣耀', name: 'Magic8', releaseDate: '2025-10', chipset: '骁龙8 Gen3', screen: '6.78英寸 OLED', battery: '5600mAh', sourceUrl: 'https://www.honor.com/cn/products/magic8/'),
  Phone(brand: '荣耀', name: 'GT Pro', releaseDate: '2025-09', chipset: '骁龙8 Gen3', screen: '6.78英寸 OLED', battery: '5800mAh', sourceUrl: 'https://www.honor.com/cn/products/gt-pro/'),

  // ==========================================
  // ---------- 三星 ----------
  // ==========================================
  Phone(brand: '三星', name: 'Galaxy S24', releaseDate: '2024年1月', chipset: '骁龙8 Gen3', screen: '6.2英寸 Dynamic AMOLED 2X', battery: '4000mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s24/'),
  Phone(brand: '三星', name: 'Galaxy S24+', releaseDate: '2024年1月', chipset: '骁龙8 Gen3', screen: '6.7英寸 Dynamic AMOLED 2X', battery: '4900mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s24-plus/'),
  Phone(brand: '三星', name: 'Galaxy S24 Ultra', releaseDate: '2024年1月', chipset: '骁龙8 Gen3', screen: '6.8英寸 Dynamic AMOLED 2X', battery: '5000mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s24-ultra/'),
  Phone(brand: '三星', name: 'Galaxy S25', releaseDate: '2025年1月', chipset: '骁龙8至尊版for Galaxy', screen: '6.2英寸 Dynamic AMOLED 2X', battery: '4000mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s25/'),
  Phone(brand: '三星', name: 'Galaxy S25+', releaseDate: '2025年1月', chipset: '骁龙8至尊版for Galaxy', screen: '6.7英寸 Dynamic AMOLED 2X', battery: '4900mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s25-plus/'),
  Phone(brand: '三星', name: 'Galaxy Z Fold6', releaseDate: '2024年7月', chipset: '骁龙8 Gen3', screen: '7.6英寸 折叠屏', battery: '4400mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-z-fold6/'),
  Phone(brand: '三星', name: 'Galaxy Z Fold7', releaseDate: '2025年7月', chipset: '骁龙8至尊版for Galaxy', screen: '8.0英寸 折叠屏', battery: '4400mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-z-fold7/'),
  Phone(brand: '三星', name: 'Galaxy Z Flip5', releaseDate: '2023年7月', chipset: '骁龙8 Gen3', screen: '6.7英寸 折叠屏', battery: '3700mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-z-flip5/'),
  Phone(brand: '三星', name: 'Galaxy Z Flip6', releaseDate: '2024年7月', chipset: '骁龙8 Gen3', screen: '6.7英寸 折叠屏', battery: '4000mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-z-flip6/'),
  Phone(brand: '三星', name: 'Galaxy A56 5G', releaseDate: '2025年3月', chipset: 'Exynos 1580', screen: '6.7英寸 AMOLED', battery: '5000mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-a56-5g/'),
  Phone(brand: '三星', name: 'Galaxy S23', releaseDate: '2023年2月', chipset: '骁龙8 Gen2', screen: '6.1英寸 Dynamic AMOLED 2X', battery: '3900mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s23/'),
  Phone(brand: '三星', name: 'Galaxy S23+', releaseDate: '2023年2月', chipset: '骁龙8 Gen2', screen: '6.6英寸 Dynamic AMOLED 2X', battery: '4700mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s23-plus/'),
  Phone(brand: '三星', name: 'Galaxy S23 Ultra', releaseDate: '2023年2月', chipset: '骁龙8 Gen2 for Galaxy', screen: '6.8英寸 Dynamic AMOLED 2X', battery: '5000mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s23-ultra/'),
  Phone(brand: '三星', name: 'Galaxy Z Fold5', releaseDate: '2023年8月', chipset: '骁龙8 Gen2', screen: '7.6英寸 折叠屏', battery: '4400mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-z-fold5/'),
  Phone(brand: '三星', name: 'Galaxy Z Flip4', releaseDate: '2022年8月', chipset: '骁龙8 Gen1', screen: '6.7英寸 折叠屏', battery: '3700mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-z-flip4/'),
  Phone(brand: '三星', name: 'Galaxy A55 5G', releaseDate: '2024年3月', chipset: 'Exynos 1580', screen: '6.6英寸 AMOLED', battery: '5000mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-a55-5g/'),
  // 截图旧版数据
  Phone(brand: '三星', name: 'Galaxy S26 Ultra', releaseDate: '2026-03', chipset: '骁龙8至尊版Gen5', screen: '6.9英寸 Dynamic AMOLED 2X', battery: '5000mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s26-ultra/'),
  Phone(brand: '三星', name: 'Galaxy S25 Ultra', releaseDate: '2025-02', chipset: '骁龙8至尊版', screen: '6.9英寸 Dynamic AMOLED 2X', battery: '5000mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s25-ultra/'),
  Phone(brand: '三星', name: 'Galaxy S25 FE', releaseDate: '2025-09', chipset: '骁龙8 Gen3', screen: '6.7英寸 AMOLED', battery: '4500mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s25-fe/'),

  // ==========================================
  // ---------- 一加 ----------
  // ==========================================
  Phone(brand: '一加', name: '一加12', releaseDate: '2023年12月', chipset: '骁龙8 Gen3', screen: '6.82英寸 2K AMOLED', battery: '5400mAh', sourceUrl: 'https://www.oneplus.com/cn/12/'),
  Phone(brand: '一加', name: '一加13', releaseDate: '2024年10月', chipset: '骁龙8至尊版', screen: '6.82英寸 2K AMOLED', battery: '6000mAh', sourceUrl: 'https://www.oneplus.com/cn/13/'),
  Phone(brand: '一加', name: '一加Ace 3', releaseDate: '2024年1月', chipset: '骁龙8 Gen3', screen: '6.78英寸 AMOLED', battery: '5500mAh', sourceUrl: 'https://www.oneplus.com/cn/ace3/'),
  Phone(brand: '一加', name: '一加Ace 3 Pro', releaseDate: '2024年7月', chipset: '骁龙8 Gen3', screen: '6.78英寸 AMOLED', battery: '6000mAh', sourceUrl: 'https://www.oneplus.com/cn/ace3pro/'),
  Phone(brand: '一加', name: '一加11', releaseDate: '2023年1月', chipset: '骁龙8 Gen2', screen: '6.74英寸 2K AMOLED', battery: '5000mAh', sourceUrl: 'https://www.oneplus.com/cn/11/'),
  Phone(brand: '一加', name: '一加Ace 2', releaseDate: '2023年2月', chipset: '骁龙8+ Gen1', screen: '6.74英寸 1.5K AMOLED', battery: '5000mAh', sourceUrl: 'https://www.oneplus.com/cn/ace2/'),
  Phone(brand: '一加', name: '一加Ace 3V', releaseDate: '2024年3月', chipset: '第三代骁龙7+', screen: '6.78英寸 AMOLED', battery: '5500mAh', sourceUrl: 'https://www.oneplus.com/cn/ace3v/'),
  Phone(brand: '一加', name: '一加Ace 5', releaseDate: '2025年', chipset: '骁龙8至尊版', screen: '6.78英寸 2K AMOLED', battery: '6000mAh', sourceUrl: 'https://www.oneplus.com/cn/ace5/'),
  Phone(brand: '一加', name: '一加Ace 5 Pro', releaseDate: '2025年', chipset: '骁龙8至尊版', screen: '6.78英寸 2K AMOLED', battery: '6500mAh', sourceUrl: 'https://www.oneplus.com/cn/ace5pro/'),
  // 截图旧版数据
  Phone(brand: '一加', name: '一加 15', releaseDate: '2025-12', chipset: '第五代骁龙8至尊版', screen: '6.82英寸 2K AMOLED', battery: '6000mAh', sourceUrl: 'https://www.oneplus.com/cn/15/'),
  Phone(brand: '一加', name: 'Ace 6', releaseDate: '2025-10', chipset: '骁龙8至尊版', screen: '6.83英寸 1.5K OLED', battery: '7800mAh', sourceUrl: 'https://www.oneplus.com/cn/ace6/'),

  // ==========================================
  // ---------- realme ----------
  // ==========================================
  Phone(brand: 'realme', name: 'GT5', releaseDate: '2024年5月', chipset: '骁龙8 Gen3', screen: '6.78英寸 2K AMOLED', battery: '5400mAh', sourceUrl: 'https://www.realme.com/cn/gt5/'),
  Phone(brand: 'realme', name: 'GT6', releaseDate: '2025年4月', chipset: '骁龙8至尊版', screen: '6.78英寸 2K AMOLED', battery: '6000mAh', sourceUrl: 'https://www.realme.com/cn/gt6/'),
  Phone(brand: 'realme', name: 'GT Neo5', releaseDate: '2023年', chipset: '骁龙8+ Gen1', screen: '6.74英寸 1.5K AMOLED', battery: '5000mAh', sourceUrl: 'https://www.realme.com/cn/gtneo5/'),
  Phone(brand: 'realme', name: 'GT3', releaseDate: '2023年', chipset: '骁龙8 Gen2', screen: '6.74英寸 1.5K AMOLED', battery: '5000mAh', sourceUrl: 'https://www.realme.com/cn/gt3/'),
  Phone(brand: 'realme', name: '13', releaseDate: '2024年', chipset: '天玑6300', screen: '6.72英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.realme.com/cn/13/'),
  Phone(brand: 'realme', name: '13 Pro', releaseDate: '2024年', chipset: '天玑7300', screen: '6.67英寸 AMOLED', battery: '5000mAh', sourceUrl: 'https://www.realme.com/cn/13pro/'),
  // 截图旧版数据
  Phone(brand: 'realme', name: 'GT8', releaseDate: '2025-10', chipset: '骁龙8至尊版', screen: '6.79英寸 2K AMOLED', battery: '7000mAh', sourceUrl: 'https://www.realme.com/cn/gt8/'),
  Phone(brand: 'realme', name: 'GT8 Pro', releaseDate: '2025-10', chipset: '骁龙8至尊版Gen5', screen: '6.79英寸 2K AMOLED', battery: '7000mAh', sourceUrl: 'https://www.realme.com/cn/gt8pro/'),
];