package com.example.jijian_pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
