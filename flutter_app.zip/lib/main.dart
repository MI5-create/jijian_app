import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const JijianApp());
}

// ============================================================
// App 入口与主壳
// ============================================================

class JijianApp extends StatelessWidget {
  const JijianApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '机鉴 · 手机图鉴',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  void _switchTo(int index) {
    if (_index == index) return;
    setState(() => _index = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgBase,
      body: IndexedStack(
        index: _index,
        children: [
          const HomePage(),
          const PlaceholderPage(title: '品牌', message: '品牌入口将在后续批次接入'),
          const PlaceholderPage(title: '搜索', message: '搜索与多维筛选将在后续批次接入'),
          const PlaceholderPage(title: '收藏', message: '收藏本地持久化将在后续批次接入'),
          const PlaceholderPage(title: '我的', message: '关于与隐私页将在后续批次接入'),
        ],
      ),
      bottomNavigationBar: GlassBottomNav(
        currentIndex: _index,
        onTap: _switchTo,
      ),
    );
  }
}

// ============================================================
// 主题 Token
// ============================================================

class AppColors {
  AppColors._();

  static const bgBase = Color(0xFF070B14);
  static const bgElevated = Color(0xFF0B1220);

  static const surface1 = Color(0xFF101A2C);
  static const surface2 = Color(0xFF15223A);
  static const surface3 = Color(0xFF1B2B47);

  static const glassFillLow = Color.fromRGBO(18, 30, 52, 0.54);
  static const glassFillMedium = Color.fromRGBO(18, 30, 52, 0.62);
  static const glassFillHigh = Color.fromRGBO(24, 38, 64, 0.70);

  static const glassStrokeTop = Color.fromRGBO(255, 255, 255, 0.28);
  static const glassStrokeBottom = Color.fromRGBO(255, 255, 255, 0.06);

  static const primary = Color(0xFF45D6FF);
  static const primaryPressed = Color(0xFF2BBBE6);
  static const primarySoft = Color.fromRGBO(69, 214, 255, 0.14);
  static const violet = Color(0xFF9B7BFF);
  static const violetPressed = Color(0xFF7F5DF0);
  static const violetSoft = Color.fromRGBO(155, 123, 255, 0.14);
  static const accentOrange = Color(0xFFFFB05C);
  static const accentOrangeSoft = Color.fromRGBO(255, 176, 92, 0.12);

  static const textPrimary = Color(0xFFF4F8FF);
  static const textSecondary = Color(0xFFB7C4D9);
  static const textTertiary = Color(0xFF7C8AA3);
  static const textOnGlass = Color(0xFFEAF2FF);
  static const textOnAccent = Color(0xFF06121F);

  static const success = Color(0xFF3DDC97);
  static const warning = Color(0xFFFFC266);
  static const error = Color(0xFFFF6B81);
}

class AppSpacing {
  AppSpacing._();
  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 20.0;
  static const xxl = 24.0;
  static const xxxl = 32.0;
}

class AppRadius {
  AppRadius._();
  static const sm = 12.0;
  static const md = 16.0;
  static const lg = 20.0;
  static const xl = 24.0;
  static const pill = 999.0;
}

class AppShadows {
  AppShadows._();
  static const card = BoxShadow(
    color: Color.fromRGBO(0, 0, 0, 0.32),
    blurRadius: 32,
    offset: Offset(0, 12),
  );
}

class GlassTokens {
  GlassTokens._();
  static const double blurLow = 16;
  static const double blurMedium = 24;
  static const double blurHigh = 32;
}

class MotionTokens {
  MotionTokens._();
  static const press = Duration(milliseconds: 120);
  static const base = Duration(milliseconds: 300);
  static const curveStandard = Cubic(0.2, 0.8, 0.2, 1);
}

ThemeData buildAppTheme() {
  final base = ThemeData.dark(useMaterial3: true);

  return base.copyWith(
    scaffoldBackgroundColor: AppColors.bgBase,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.primary,
      secondary: AppColors.violet,
      surface: AppColors.surface1,
      error: AppColors.error,
      onPrimary: AppColors.textOnAccent,
      onSurface: AppColors.textPrimary,
    ),
    textTheme: const TextTheme(
      displayLarge: TextStyle(
        fontSize: 32,
        height: 40 / 32,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.4,
        color: AppColors.textPrimary,
      ),
      headlineMedium: TextStyle(
        fontSize: 24,
        height: 32 / 24,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.2,
        color: AppColors.textPrimary,
      ),
      titleMedium: TextStyle(
        fontSize: 17,
        height: 24 / 17,
        fontWeight: FontWeight.w600,
        color: AppColors.textPrimary,
      ),
      bodyMedium: TextStyle(
        fontSize: 15,
        height: 22 / 15,
        fontWeight: FontWeight.w400,
        color: AppColors.textPrimary,
      ),
      labelMedium: TextStyle(
        fontSize: 13,
        height: 18 / 13,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.1,
        color: AppColors.textSecondary,
      ),
      bodySmall: TextStyle(
        fontSize: 12,
        height: 18 / 12,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.1,
        color: AppColors.textSecondary,
      ),
      labelSmall: TextStyle(
        fontSize: 11,
        height: 16 / 11,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.1,
        color: AppColors.textTertiary,
      ),
    ),
  );
}

// ============================================================
// 数据模型：Phone
// 与表格列一一对应
// ============================================================

class Phone {
  final String brand;
  final String name;
  final String releaseDate;
  final String chipset;
  final String screen;
  final String battery;
  final String sourceUrl;

  const Phone({
    required this.brand,
    required this.name,
    required this.releaseDate,
    required this.chipset,
    required this.screen,
    required this.battery,
    required this.sourceUrl,
  });

  /// 从表格行 Map 构造，便于后续接入 CSV / Excel 解析
  factory Phone.fromMap(Map<String, String> row) {
    return Phone(
      brand: row['brand'] ?? '',
      name: row['name'] ?? '',
      releaseDate: row['releaseDate'] ?? '',
      chipset: row['chipset'] ?? '',
      screen: row['screen'] ?? '',
      battery: row['battery'] ?? '',
      sourceUrl: row['sourceUrl'] ?? '',
    );
  }

  /// 中文友好展示：2025-11 → 2025 年 11 月
  String get displayReleaseDate {
    final parts = releaseDate.split('-');
    if (parts.length == 2) {
      final year = parts[0];
      final month = int.tryParse(parts[1]);
      if (month != null) return '$year 年 $month 月';
    }
    return releaseDate;
  }

  String get displayDomain {
    try {
      return Uri.parse(sourceUrl).host;
    } catch (_) {
      return sourceUrl;
    }
  }
}

// ============================================================
// 全量机型数据（来自用户表格）
// ============================================================

final List<Phone> allPhones = const [
  // ---------- 华为 ----------
  Phone(
    brand: '华为',
    name: 'Mate 80',
    releaseDate: '2025-11',
    chipset: '麒麟 9020',
    screen: '6.75英寸 OLED',
    battery: '5750mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80/',
  ),
  Phone(
    brand: '华为',
    name: 'Mate 80 Pro',
    releaseDate: '2025-11',
    chipset: '麒麟 9030',
    screen: '6.75英寸 OLED',
    battery: '5750mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80pro/',
  ),
  Phone(
    brand: '华为',
    name: 'Mate 80 Pro Max',
    releaseDate: '2025-11',
    chipset: '麒麟 9030 Pro',
    screen: '6.9英寸 OLED',
    battery: '6000mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80promax/',
  ),
  Phone(
    brand: '华为',
    name: 'Mate 80 RS 非凡大师',
    releaseDate: '2025-11',
    chipset: '麒麟 9030 Pro',
    screen: '6.9英寸 OLED',
    battery: '6000mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80rs/',
  ),
  Phone(
    brand: '华为',
    name: 'Pura 80',
    releaseDate: '2025-06',
    chipset: '麒麟 9010S',
    screen: '6.6英寸 OLED',
    battery: '5600mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/pura80/',
  ),
  Phone(
    brand: '华为',
    name: 'Pura 80 Pro',
    releaseDate: '2025-06',
    chipset: '麒麟 9020',
    screen: '6.8英寸 OLED',
    battery: '5700mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/pura80pro/',
  ),
  Phone(
    brand: '华为',
    name: 'Pura 80 Ultra',
    releaseDate: '2025-06',
    chipset: '麒麟 9020',
    screen: '6.8英寸 OLED',
    battery: '5700mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/pura80ultra/',
  ),
  Phone(
    brand: '华为',
    name: 'Mate X7',
    releaseDate: '2025-11',
    chipset: '麒麟 9020',
    screen: '折叠屏 OLED',
    battery: '5750mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/matex7/',
  ),
  Phone(
    brand: '华为',
    name: 'nova 14',
    releaseDate: '2025-05',
    chipset: '麒麟9010',
    screen: '6.7英寸 OLED',
    battery: '5000mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/nova14/',
  ),
  Phone(
    brand: '华为',
    name: 'Mate XT 非凡大师',
    releaseDate: '2025-04',
    chipset: '麒麟9020',
    screen: '三折叠屏 OLED',
    battery: '6000mAh',
    sourceUrl: 'https://consumer.huawei.com/cn/phone/matext/',
  ),

  // ---------- 苹果 ----------
  Phone(
    brand: '苹果',
    name: 'iPhone 17',
    releaseDate: '2025-09',
    chipset: 'A19',
    screen: '6.3英寸 OLED',
    battery: '3692mAh',
    sourceUrl: 'https://www.apple.com/iphone-17/',
  ),
  Phone(
    brand: '苹果',
    name: 'iPhone 17 Air',
    releaseDate: '2025-09',
    chipset: 'A19 Pro',
    screen: '6.5英寸 OLED',
    battery: '3149mAh',
    sourceUrl: 'https://www.apple.com/iphone-air/',
  ),
  Phone(
    brand: '苹果',
    name: 'iPhone 17 Pro',
    releaseDate: '2025-09',
    chipset: 'A19 Pro',
    screen: '6.3英寸 OLED',
    battery: '3988mAh',
    sourceUrl: 'https://www.apple.com/iphone-17-pro/',
  ),
  Phone(
    brand: '苹果',
    name: 'iPhone 17 Pro Max',
    releaseDate: '2025-09',
    chipset: 'A19 Pro',
    screen: '6.9英寸 OLED',
    battery: '4832mAh',
    sourceUrl: 'https://www.apple.com/iphone-17-pro-max/',
  ),

  // ---------- 小米 ----------
  Phone(
    brand: '小米',
    name: 'Xiaomi 17',
    releaseDate: '2025-09',
    chipset: '第五代骁龙8至尊版',
    screen: '6.3英寸 OLED',
    battery: '7000mAh',
    sourceUrl: 'https://www.mi.com/xiaomi17/',
  ),
  Phone(
    brand: '小米',
    name: 'Xiaomi 17 Pro',
    releaseDate: '2025-09',
    chipset: '第五代骁龙8至尊版',
    screen: '6.3英寸 OLED（含背屏）',
    battery: '6300mAh',
    sourceUrl: 'https://www.mi.com/xiaomi17pro/',
  ),
  Phone(
    brand: '小米',
    name: 'Xiaomi 17 Pro Max',
    releaseDate: '2025-09',
    chipset: '第五代骁龙8至尊版',
    screen: '6.9英寸 OLED',
    battery: '7500mAh',
    sourceUrl: 'https://www.mi.com/xiaomi17promax/',
  ),
  Phone(
    brand: '小米',
    name: 'Xiaomi 17 Ultra',
    releaseDate: '2026-03',
    chipset: '骁龙8至尊版',
    screen: '6.73英寸 OLED',
    battery: '5500mAh',
    sourceUrl: 'https://www.mi.com/xiaomi17ultra/',
  ),

  // ---------- OPPO ----------
  Phone(
    brand: 'OPPO',
    name: 'Find X9 Ultra',
    releaseDate: '2026-04',
    chipset: '第五代骁龙8至尊版',
    screen: '6.82英寸 2K AMOLED',
    battery: '7050mAh',
    sourceUrl: 'https://www.oppo.com/cn/phones/find-x9-ultra/',
  ),
  Phone(
    brand: 'OPPO',
    name: 'Find X9 Pro',
    releaseDate: '2025-10',
    chipset: '天玑9400+',
    screen: '6.78英寸 AMOLED',
    battery: '5900mAh',
    sourceUrl: 'https://www.oppo.com/cn/phones/find-x9-pro/',
  ),
  Phone(
    brand: 'OPPO',
    name: 'Find X8 Ultra',
    releaseDate: '2025-04',
    chipset: '骁龙8至尊版',
    screen: '6.82英寸 2K AMOLED',
    battery: '6100mAh',
    sourceUrl: 'https://www.oppo.com/cn/phones/find-x8-ultra/',
  ),
  Phone(
    brand: 'OPPO',
    name: 'Reno 15',
    releaseDate: '2025-08',
    chipset: '天玑7300',
    screen: '6.67英寸 OLED',
    battery: '5000mAh',
    sourceUrl: 'https://www.oppo.com/cn/phones/reno15/',
  ),
  Phone(
    brand: 'OPPO',
    name: 'Reno 15 Pro',
    releaseDate: '2025-08',
    chipset: '天玑9300+',
    screen: '6.78英寸 OLED',
    battery: '5500mAh',
    sourceUrl: 'https://www.oppo.com/cn/phones/reno15pro/',
  ),
  Phone(
    brand: 'OPPO',
    name: 'Find N5',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版',
    screen: '折叠屏 AMOLED',
    battery: '5500mAh',
    sourceUrl: 'https://www.oppo.com/cn/phones/find-n5/',
  ),

  // ---------- vivo ----------
  Phone(
    brand: 'vivo',
    name: 'X300 Ultra',
    releaseDate: '2026-03',
    chipset: '第五代骁龙8至尊版',
    screen: '6.82英寸 2K OLED',
    battery: '6600mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/x300-ultra/',
  ),
  Phone(
    brand: 'vivo',
    name: 'X300 Pro',
    releaseDate: '2025-10',
    chipset: '天玑9500',
    screen: '6.78英寸 OLED',
    battery: '6510mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/x300-pro/',
  ),
  Phone(
    brand: 'vivo',
    name: 'X300',
    releaseDate: '2025-10',
    chipset: '天玑9500',
    screen: '6.31英寸 OLED',
    battery: '6040mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/x300/',
  ),
  Phone(
    brand: 'vivo',
    name: 'X200 Ultra',
    releaseDate: '2025-04',
    chipset: '骁龙8至尊版',
    screen: '6.82英寸 2K OLED',
    battery: '6000mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/x200-ultra/',
  ),
  Phone(
    brand: 'vivo',
    name: 'X200s',
    releaseDate: '2025-07',
    chipset: '天玑9400+',
    screen: '6.78英寸 OLED',
    battery: '6000mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/x200s/',
  ),
  Phone(
    brand: 'vivo',
    name: 'S30',
    releaseDate: '2025-05',
    chipset: '天玑9300+',
    screen: '6.67英寸 OLED',
    battery: '5800mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/s30/',
  ),
  Phone(
    brand: 'vivo',
    name: 'S50',
    releaseDate: '2025-12',
    chipset: '第三代骁龙8s',
    screen: '6.59英寸 OLED',
    battery: '6500mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/s50/',
  ),
  Phone(
    brand: 'vivo',
    name: 'X Fold6',
    releaseDate: '2026-06',
    chipset: '天玑9500超能版',
    screen: '折叠屏 OLED',
    battery: '7000mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/xfold6/',
  ),
  Phone(
    brand: 'vivo',
    name: 'Y500',
    releaseDate: '2025-09',
    chipset: '天玑7300',
    screen: '6.67英寸 OLED',
    battery: '6000mAh',
    sourceUrl: 'https://www.vivo.com/cn/phones/y500/',
  ),

  // ---------- 荣耀 ----------
  Phone(
    brand: '荣耀',
    name: 'Magic8 Pro',
    releaseDate: '2026-03',
    chipset: '第五代骁龙8至尊版',
    screen: '6.71英寸 OLED',
    battery: '5900mAh',
    sourceUrl: 'https://www.honor.com/cn/products/magic8-pro/',
  ),
  Phone(
    brand: '荣耀',
    name: 'Magic V5',
    releaseDate: '2025-07',
    chipset: '骁龙8至尊版',
    screen: '7.95英寸 折叠屏 OLED',
    battery: '5820mAh',
    sourceUrl: 'https://www.honor.com/cn/products/magicv5/',
  ),
  Phone(
    brand: '荣耀',
    name: '500',
    releaseDate: '2025-11',
    chipset: '骁龙8 Gen2',
    screen: '6.7英寸 OLED',
    battery: '8000mAh',
    sourceUrl: 'https://www.honor.com/cn/products/500/',
  ),
  Phone(
    brand: '荣耀',
    name: '500 Pro',
    releaseDate: '2025-11',
    chipset: '骁龙8 Gen3',
    screen: '6.78英寸 OLED',
    battery: '6000mAh',
    sourceUrl: 'https://www.honor.com/cn/products/500pro/',
  ),
  Phone(
    brand: '荣耀',
    name: 'Magic8',
    releaseDate: '2025-10',
    chipset: '骁龙8 Gen3',
    screen: '6.78英寸 OLED',
    battery: '5600mAh',
    sourceUrl: 'https://www.honor.com/cn/products/magic8/',
  ),
  Phone(
    brand: '荣耀',
    name: 'GT Pro',
    releaseDate: '2025-09',
    chipset: '骁龙8 Gen3',
    screen: '6.78英寸 OLED',
    battery: '5800mAh',
    sourceUrl: 'https://www.honor.com/cn/products/gt-pro/',
  ),

  // ---------- 一加 ----------
  Phone(
    brand: '一加',
    name: '一加 15',
    releaseDate: '2025-12',
    chipset: '第五代骁龙8至尊版',
    screen: '6.82英寸 2K AMOLED',
    battery: '6000mAh',
    sourceUrl: 'https://www.oneplus.com/cn/15/',
  ),
  Phone(
    brand: '一加',
    name: 'Ace 6',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版',
    screen: '6.83英寸 1.5K OLED',
    battery: '7800mAh',
    sourceUrl: 'https://www.oneplus.com/cn/ace6/',
  ),

  // ---------- 三星 ----------
  Phone(
    brand: '三星',
    name: 'Galaxy S26 Ultra',
    releaseDate: '2026-03',
    chipset: '骁龙8至尊版Gen5',
    screen: '6.9英寸 Dynamic AMOLED 2X',
    battery: '5000mAh',
    sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s26-ultra/',
  ),
  Phone(
    brand: '三星',
    name: 'Galaxy S25 Ultra',
    releaseDate: '2025-02',
    chipset: '骁龙8至尊版',
    screen: '6.9英寸 Dynamic AMOLED 2X',
    battery: '5000mAh',
    sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s25-ultra/',
  ),
  Phone(
    brand: '三星',
    name: 'Galaxy S25 FE',
    releaseDate: '2025-09',
    chipset: '骁龙8 Gen3',
    screen: '6.7英寸 AMOLED',
    battery: '4500mAh',
    sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s25-fe/',
  ),

  // ---------- realme ----------
  Phone(
    brand: 'realme',
    name: 'GT8',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版',
    screen: '6.79英寸 2K AMOLED',
    battery: '7000mAh',
    sourceUrl: 'https://www.realme.com/cn/gt8/',
  ),
  Phone(
    brand: 'realme',
    name: 'GT8 Pro',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版Gen5',
    screen: '6.79英寸 2K AMOLED',
    battery: '7000mAh',
    sourceUrl: 'https://www.realme.com/cn/gt8pro/',
  ),

  // ---------- Redmi ----------
  Phone(
    brand: 'Redmi',
    name: 'K90',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版',
    screen: '6.59英寸 OLED',
    battery: '7100mAh',
    sourceUrl: 'https://www.mi.com/redmik90/',
  ),
  Phone(
    brand: 'Redmi',
    name: 'K90 Pro Max',
    releaseDate: '2025-10',
    chipset: '第五代骁龙8至尊版',
    screen: '6.9英寸 OLED',
    battery: '7560mAh',
    sourceUrl: 'https://www.mi.com/redmik90promax/',
  ),
  Phone(
    brand: 'Redmi',
    name: 'K90 Pro',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版',
    screen: '6.67英寸 OLED',
    battery: '6400mAh',
    sourceUrl: 'https://www.mi.com/redmik90pro/',
  ),

  // ---------- iQOO ----------
  Phone(
    brand: 'iQOO',
    name: '15',
    releaseDate: '2025-10',
    chipset: '骁龙8至尊版',
    screen: '6.78英寸 AMOLED',
    battery: '6000mAh',
    sourceUrl: 'https://www.iqoo.com/cn/phone-iqoo15/',
  ),
];

/// 按品牌分组，保持原表格插入顺序（LinkedHashMap）
Map<String, List<Phone>> groupByBrand(List<Phone> phones) {
  final map = <String, List<Phone>>{};
  for (final p in phones) {
    map.putIfAbsent(p.brand, () => <Phone>[]).add(p);
  }
  return map;
}

// ============================================================
// 背景：深空蓝黑 + 青蓝/紫罗兰光晕 + 网格
// ============================================================

class GradientMeshBackground extends StatelessWidget {
  final Widget child;

  const GradientMeshBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(color: AppColors.bgBase),
        Positioned.fill(
          child: IgnorePointer(
            child: CustomPaint(painter: _GridPainter()),
          ),
        ),
        Positioned(
          top: -220,
          left: -140,
          child: _RadialGlow(
            size: 600,
            color: AppColors.primary,
            opacity: 0.18,
            stop: 0.6,
          ),
        ),
        Positioned(
          top: 60,
          right: -180,
          child: _RadialGlow(
            size: 560,
            color: AppColors.violet,
            opacity: 0.16,
            stop: 0.65,
          ),
        ),
        Positioned(
          bottom: -180,
          left: 60,
          child: _RadialGlow(
            size: 500,
            color: AppColors.accentOrange,
            opacity: 0.06,
            stop: 0.7,
          ),
        ),
        child,
      ],
    );
  }
}

class _RadialGlow extends StatelessWidget {
  final double size;
  final Color color;
  final double opacity;
  final double stop;

  const _RadialGlow({
    required this.size,
    required this.color,
    required this.opacity,
    required this.stop,
  });

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [color.withOpacity(opacity), Colors.transparent],
            stops: [0, stop],
          ),
        ),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.035)
      ..strokeWidth = 1;

    const gap = 24.0;
    for (double x = 0; x <= size.width; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ============================================================
// 液态玻璃卡片
// ============================================================

enum GlassLevel { low, medium, high }

class LiquidGlassCard extends StatefulWidget {
  final Widget child;
  final GlassLevel level;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry? padding;
  final double? borderRadius;

  const LiquidGlassCard({
    super.key,
    required this.child,
    this.level = GlassLevel.medium,
    this.onTap,
    this.padding,
    this.borderRadius,
  });

  @override
  State<LiquidGlassCard> createState() => _LiquidGlassCardState();
}

class _LiquidGlassCardState extends State<LiquidGlassCard> {
  bool _pressed = false;

  double get _blur {
    switch (widget.level) {
      case GlassLevel.low:
        return GlassTokens.blurLow;
      case GlassLevel.medium:
        return GlassTokens.blurMedium;
      case GlassLevel.high:
        return GlassTokens.blurHigh;
    }
  }

  Color get _fill {
    switch (widget.level) {
      case GlassLevel.low:
        return AppColors.glassFillLow;
      case GlassLevel.medium:
        return AppColors.glassFillMedium;
      case GlassLevel.high:
        return AppColors.glassFillHigh;
    }
  }

  Color get _strokeTop {
    switch (widget.level) {
      case GlassLevel.low:
        return const Color.fromRGBO(255, 255, 255, 0.24);
      case GlassLevel.medium:
        return const Color.fromRGBO(255, 255, 255, 0.28);
      case GlassLevel.high:
        return const Color.fromRGBO(255, 255, 255, 0.32);
    }
  }

  Color get _strokeBottom {
    switch (widget.level) {
      case GlassLevel.low:
        return const Color.fromRGBO(255, 255, 255, 0.04);
      case GlassLevel.medium:
        return const Color.fromRGBO(255, 255, 255, 0.06);
      case GlassLevel.high:
        return const Color.fromRGBO(255, 255, 255, 0.08);
    }
  }

  @override
  Widget build(BuildContext context) {
    final reduced = MediaQuery.maybeDisableAnimationsOf(context) ?? false;
    final radius = widget.borderRadius ?? AppRadius.lg;

    return GestureDetector(
      onTapDown: widget.onTap == null
          ? null
          : (_) => setState(() => _pressed = true),
      onTapUp: widget.onTap == null
          ? null
          : (_) {
              setState(() => _pressed = false);
              widget.onTap!();
            },
      onTapCancel: widget.onTap == null
          ? null
          : () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed && !reduced ? 0.985 : 1,
        duration: reduced ? Duration.zero : MotionTokens.press,
        curve: MotionTokens.curveStandard,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [_strokeTop, _strokeBottom],
            ),
            boxShadow: const [AppShadows.card],
          ),
          padding: const EdgeInsets.all(0.5),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(radius - 0.5),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: _blur, sigmaY: _blur),
              child: Container(
                padding: widget.padding ?? const EdgeInsets.all(AppSpacing.lg),
                decoration: BoxDecoration(
                  color: _fill,
                  borderRadius: BorderRadius.circular(radius - 0.5),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.center,
                    colors: [
                      Colors.white.withOpacity(0.08),
                      Colors.transparent,
                    ],
                  ),
                ),
                child: widget.child,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// 机型卡片
// ============================================================

class PhoneCard extends StatelessWidget {
  final Phone phone;

  const PhoneCard({super.key, required this.phone});

  @override
  Widget build(BuildContext context) {
    return LiquidGlassCard(
      level: GlassLevel.medium,
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 型号名
          Text(
            phone.name,
            style: const TextStyle(
              fontSize: 17,
              height: 24 / 17,
              fontWeight: FontWeight.w600,
              color: AppColors.textOnGlass,
              letterSpacing: 0,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 6),
          // 发布时间 · 芯片
          Row(
            children: [
              Text(
                phone.displayReleaseDate,
                style: const TextStyle(
                  fontSize: 12,
                  height: 18 / 12,
                  color: AppColors.textSecondary,
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 6),
                child: _Dot(),
              ),
              Flexible(
                child: Text(
                  phone.chipset,
                  style: const TextStyle(
                    fontSize: 12,
                    height: 18 / 12,
                    color: AppColors.textSecondary,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // 屏幕 / 电池
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: [
              _SpecChip(label: phone.screen),
              _SpecChip(label: phone.battery),
            ],
          ),
          const SizedBox(height: 12),
          // 来源链接
          _SourceRow(
            url: phone.sourceUrl,
            domain: phone.displayDomain,
            onTap: () {
              Clipboard.setData(ClipboardData(text: phone.sourceUrl));
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: const Text('来源链接已复制'),
                  behavior: SnackBarBehavior.floating,
                  backgroundColor: AppColors.surface2,
                  duration: const Duration(seconds: 2),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppRadius.md),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _Dot extends StatelessWidget {
  const _Dot();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 3,
      height: 3,
      decoration: const BoxDecoration(
        color: AppColors.textTertiary,
        shape: BoxShape.circle,
      ),
    );
  }
}

class _SpecChip extends StatelessWidget {
  final String label;

  const _SpecChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(AppRadius.pill),
        border: Border.all(
          color: Colors.white.withOpacity(0.06),
          width: 0.5,
        ),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 11,
          height: 16 / 11,
          fontWeight: FontWeight.w500,
          color: AppColors.textSecondary,
        ),
      ),
    );
  }
}

class _SourceRow extends StatelessWidget {
  final String url;
  final String domain;
  final VoidCallback onTap;

  const _SourceRow({
    required this.url,
    required this.domain,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            const Icon(
              Icons.link_rounded,
              size: 14,
              color: AppColors.primary,
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                domain,
                style: const TextStyle(
                  fontSize: 11,
                  height: 16 / 11,
                  fontWeight: FontWeight.w500,
                  color: AppColors.primary,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(width: 6),
            const Icon(
              Icons.copy_rounded,
              size: 12,
              color: AppColors.textTertiary,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// 品牌标题：渐变色 / 高光效果
// ============================================================

class BrandHeader extends StatelessWidget {
  final String brand;
  final int count;

  const BrandHeader({
    super.key,
    required this.brand,
    required this.count,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.xl,
        AppSpacing.xxl,
        AppSpacing.xl,
        AppSpacing.md,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.baseline,
        textBaseline: TextBaseline.alphabetic,
        children: [
          ShaderMask(
            shaderCallback: (rect) => const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFFFFFFFF), // 顶部高光
                Color(0xFF45D6FF), // 青蓝
                Color(0xFF9B7BFF), // 紫罗兰
              ],
              stops: [0.0, 0.4, 1.0],
            ).createShader(rect),
            blendMode: BlendMode.srcIn,
            child: Text(
              brand,
              style: const TextStyle(
                fontSize: 28,
                height: 36 / 28,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.4,
                color: Colors.white, // 实际颜色由 ShaderMask 决定
              ),
            ),
          ),
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(AppRadius.pill),
              border: Border.all(
                color: Colors.white.withOpacity(0.08),
                width: 0.5,
              ),
            ),
            child: Text(
              '$count 款',
              style: const TextStyle(
                fontSize: 11,
                height: 16 / 11,
                fontWeight: FontWeight.w500,
                color: AppColors.textTertiary,
                letterSpacing: 0.2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// 首页：按品牌分组渲染
// ============================================================

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late final Map<String, List<Phone>> _grouped;

  @override
  void initState() {
    super.initState();
    _grouped = groupByBrand(allPhones);
  }

  @override
  Widget build(BuildContext context) {
    final brands = _grouped.keys.toList();

    return GradientMeshBackground(
      child: SafeArea(
        bottom: false,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            // 顶部
            SliverToBoxAdapter(child: _buildHeader()),

            // 品牌分组
            SliverList.builder(
              itemCount: brands.length,
              itemBuilder: (context, index) {
                final brand = brands[index];
                final phones = _grouped[brand]!;
                return _buildBrandSection(brand, phones);
              },
            ),

            // 底部留白，避免遮挡悬浮导航
            const SliverToBoxAdapter(child: SizedBox(height: 100)),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.xl,
        AppSpacing.lg,
        AppSpacing.xl,
        AppSpacing.xs,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: ShaderMask(
                  shaderCallback: (rect) => const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFFFFFFFF),
                      Color(0xFF45D6FF),
                      Color(0xFF9B7BFF),
                    ],
                    stops: [0.0, 0.5, 1.0],
                  ).createShader(rect),
                  blendMode: BlendMode.srcIn,
                  child: const Text(
                    '机鉴',
                    style: TextStyle(
                      fontSize: 36,
                      height: 44 / 36,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.6,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.08),
                    width: 0.6,
                  ),
                ),
                child: Text(
                  '${allPhones.length} 款机型',
                  style: const TextStyle(
                    fontSize: 12,
                    height: 16 / 12,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textSecondary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          const Text(
            '按品牌分类 · 数据来源：厂商公开规格页 · 点击来源可复制',
            style: TextStyle(
              fontSize: 12,
              height: 18 / 12,
              color: AppColors.textTertiary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBrandSection(String brand, List<Phone> phones) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        BrandHeader(brand: brand, count: phones.length),
        ...phones.map(
          (phone) => Padding(
            padding: const EdgeInsets.fromLTRB(
              AppSpacing.xl,
              0,
              AppSpacing.xl,
              AppSpacing.md,
            ),
            child: PhoneCard(phone: phone),
          ),
        ),
      ],
    );
  }
}

// ============================================================
// 底部导航
// ============================================================

class GlassBottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const GlassBottomNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  static const _items = [
    _NavItem(icon: Icons.home_outlined, selectedIcon: Icons.home, label: '首页'),
    _NavItem(icon: Icons.grid_view_outlined, selectedIcon: Icons.grid_view, label: '品牌'),
    _NavItem(icon: Icons.search_outlined, selectedIcon: Icons.search, label: '搜索'),
    _NavItem(icon: Icons.bookmark_border, selectedIcon: Icons.bookmark, label: '收藏'),
    _NavItem(icon: Icons.person_outline, selectedIcon: Icons.person, label: '我的'),
  ];

  @override
  Widget build(BuildContext context) {
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: GlassTokens.blurHigh,
          sigmaY: GlassTokens.blurHigh,
        ),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.glassFillHigh,
            border: Border(
              top: BorderSide(
                color: AppColors.glassStrokeTop,
                width: 0.6,
              ),
            ),
          ),
          child: SafeArea(
            top: false,
            child: SizedBox(
              height: 56,
              child: Row(
                children: List.generate(_items.length, (index) {
                  final selected = index == currentIndex;
                  final item = _items[index];
                  return Expanded(
                    child: InkWell(
                      onTap: () => onTap(index),
                      splashColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            selected ? item.selectedIcon : item.icon,
                            size: 24,
                            color: selected
                                ? AppColors.primary
                                : AppColors.textTertiary,
                          ),
                          const SizedBox(height: 2),
                          Text(
                            item.label,
                            style: TextStyle(
                              fontSize: 11,
                              height: 16 / 11,
                              fontWeight: FontWeight.w500,
                              color: selected
                                  ? AppColors.primary
                                  : AppColors.textTertiary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final IconData selectedIcon;
  final String label;

  const _NavItem({
    required this.icon,
    required this.selectedIcon,
    required this.label,
  });
}

// ============================================================
// 占位页
// ============================================================

class PlaceholderPage extends StatelessWidget {
  final String title;
  final String message;

  const PlaceholderPage({
    super.key,
    required this.title,
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    return GradientMeshBackground(
      child: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.xxxl),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                const SizedBox(height: AppSpacing.md),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 12,
                    height: 18 / 12,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}