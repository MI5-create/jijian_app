class Phone {
  final String brand;
  final String name;
  final String releaseDate;
  final String chipset;
  final String screen;
  final String battery;
  final String sourceUrl;

  const Phone({
    required this.brand,
    required this.name,
    required this.releaseDate,
    required this.chipset,
    required this.screen,
    required this.battery,
    required this.sourceUrl,
  });

  /// 唯一标识：品牌::型号。用于本地收藏的持久化存储。
  String get id => '$brand::$name';

  /// 格式化日期：2025-11 -> 2025 年 11 月
  String get displayReleaseDate {
    final parts = releaseDate.split('-');
    if (parts.length == 2) {
      final year = parts[0];
      final month = int.tryParse(parts[1]);
      if (month != null) return '$year 年 $month 月';
    }
    return releaseDate;
  }

  /// 获取来源链接的域名，用于展示
  String get displayDomain {
    try {
      return Uri.parse(sourceUrl).host;
    } catch (_) {
      return sourceUrl;
    }
  }
}

/// 全部机型数据
final List<Phone> allPhones = const [
  // ---------- 华为 ----------
  Phone(brand: '华为', name: 'Mate 80', releaseDate: '2025-11', chipset: '麒麟 9020', screen: '6.75英寸 OLED', battery: '5750mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80/'),
  Phone(brand: '华为', name: 'Mate 80 Pro', releaseDate: '2025-11', chipset: '麒麟 9030', screen: '6.75英寸 OLED', battery: '5750mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80pro/'),
  Phone(brand: '华为', name: 'Mate 80 Pro Max', releaseDate: '2025-11', chipset: '麒麟 9030 Pro', screen: '6.9英寸 OLED', battery: '6000mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80promax/'),
  Phone(brand: '华为', name: 'Mate 80 RS 非凡大师', releaseDate: '2025-11', chipset: '麒麟 9030 Pro', screen: '6.9英寸 OLED', battery: '6000mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/mate80rs/'),
  Phone(brand: '华为', name: 'Pura 80', releaseDate: '2025-06', chipset: '麒麟 9010S', screen: '6.6英寸 OLED', battery: '5600mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/pura80/'),
  Phone(brand: '华为', name: 'Pura 80 Pro', releaseDate: '2025-06', chipset: '麒麟 9020', screen: '6.8英寸 OLED', battery: '5700mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/pura80pro/'),
  Phone(brand: '华为', name: 'Pura 80 Ultra', releaseDate: '2025-06', chipset: '麒麟 9020', screen: '6.8英寸 OLED', battery: '5700mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/pura80ultra/'),
  Phone(brand: '华为', name: 'Mate X7', releaseDate: '2025-11', chipset: '麒麟 9020', screen: '折叠屏 OLED', battery: '5750mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/matex7/'),
  Phone(brand: '华为', name: 'nova 14', releaseDate: '2025-05', chipset: '麒麟9010', screen: '6.7英寸 OLED', battery: '5000mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/nova14/'),
  Phone(brand: '华为', name: 'Mate XT 非凡大师', releaseDate: '2025-04', chipset: '麒麟9020', screen: '三折叠屏 OLED', battery: '6000mAh', sourceUrl: 'https://consumer.huawei.com/cn/phone/matext/'),

  // ---------- 苹果 ----------
  Phone(brand: '苹果', name: 'iPhone 17', releaseDate: '2025-09', chipset: 'A19', screen: '6.3英寸 OLED', battery: '3692mAh', sourceUrl: 'https://www.apple.com/iphone-17/'),
  Phone(brand: '苹果', name: 'iPhone 17 Air', releaseDate: '2025-09', chipset: 'A19 Pro', screen: '6.5英寸 OLED', battery: '3149mAh', sourceUrl: 'https://www.apple.com/iphone-air/'),
  Phone(brand: '苹果', name: 'iPhone 17 Pro', releaseDate: '2025-09', chipset: 'A19 Pro', screen: '6.3英寸 OLED', battery: '3988mAh', sourceUrl: 'https://www.apple.com/iphone-17-pro/'),
  Phone(brand: '苹果', name: 'iPhone 17 Pro Max', releaseDate: '2025-09', chipset: 'A19 Pro', screen: '6.9英寸 OLED', battery: '4832mAh', sourceUrl: 'https://www.apple.com/iphone-17-pro-max/'),

  // ---------- 小米 ----------
  Phone(brand: '小米', name: 'Xiaomi 17', releaseDate: '2025-09', chipset: '第五代骁龙8至尊版', screen: '6.3英寸 OLED', battery: '7000mAh', sourceUrl: 'https://www.mi.com/xiaomi17/'),
  Phone(brand: '小米', name: 'Xiaomi 17 Pro', releaseDate: '2025-09', chipset: '第五代骁龙8至尊版', screen: '6.3英寸 OLED（含背屏）', battery: '6300mAh', sourceUrl: 'https://www.mi.com/xiaomi17pro/'),
  Phone(brand: '小米', name: 'Xiaomi 17 Pro Max', releaseDate: '2025-09', chipset: '第五代骁龙8至尊版', screen: '6.9英寸 OLED', battery: '7500mAh', sourceUrl: 'https://www.mi.com/xiaomi17promax/'),
  Phone(brand: '小米', name: 'Xiaomi 17 Ultra', releaseDate: '2026-03', chipset: '骁龙8至尊版', screen: '6.73英寸 OLED', battery: '5500mAh', sourceUrl: 'https://www.mi.com/xiaomi17ultra/'),

  // ---------- OPPO ----------
  Phone(brand: 'OPPO', name: 'Find X9 Ultra', releaseDate: '2026-04', chipset: '第五代骁龙8至尊版', screen: '6.82英寸 2K AMOLED', battery: '7050mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-x9-ultra/'),
  Phone(brand: 'OPPO', name: 'Find X9 Pro', releaseDate: '2025-10', chipset: '天玑9400+', screen: '6.78英寸 AMOLED', battery: '5900mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-x9-pro/'),
  Phone(brand: 'OPPO', name: 'Find X8 Ultra', releaseDate: '2025-04', chipset: '骁龙8至尊版', screen: '6.82英寸 2K AMOLED', battery: '6100mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-x8-ultra/'),
  Phone(brand: 'OPPO', name: 'Reno 15', releaseDate: '2025-08', chipset: '天玑7300', screen: '6.67英寸 OLED', battery: '5000mAh', sourceUrl: 'https://www.oppo.com/cn/phones/reno15/'),
  Phone(brand: 'OPPO', name: 'Reno 15 Pro', releaseDate: '2025-08', chipset: '天玑9300+', screen: '6.78英寸 OLED', battery: '5500mAh', sourceUrl: 'https://www.oppo.com/cn/phones/reno15pro/'),
  Phone(brand: 'OPPO', name: 'Find N5', releaseDate: '2025-10', chipset: '骁龙8至尊版', screen: '折叠屏 AMOLED', battery: '5500mAh', sourceUrl: 'https://www.oppo.com/cn/phones/find-n5/'),

  // ---------- vivo ----------
  Phone(brand: 'vivo', name: 'X300 Ultra', releaseDate: '2026-03', chipset: '第五代骁龙8至尊版', screen: '6.82英寸 2K OLED', battery: '6600mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x300-ultra/'),
  Phone(brand: 'vivo', name: 'X300 Pro', releaseDate: '2025-10', chipset: '天玑9500', screen: '6.78英寸 OLED', battery: '6510mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x300-pro/'),
  Phone(brand: 'vivo', name: 'X300', releaseDate: '2025-10', chipset: '天玑9500', screen: '6.31英寸 OLED', battery: '6040mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x300/'),
  Phone(brand: 'vivo', name: 'X200 Ultra', releaseDate: '2025-04', chipset: '骁龙8至尊版', screen: '6.82英寸 2K OLED', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x200-ultra/'),
  Phone(brand: 'vivo', name: 'X200s', releaseDate: '2025-07', chipset: '天玑9400+', screen: '6.78英寸 OLED', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/x200s/'),
  Phone(brand: 'vivo', name: 'S30', releaseDate: '2025-05', chipset: '天玑9300+', screen: '6.67英寸 OLED', battery: '5800mAh', sourceUrl: 'https://www.vivo.com/cn/phones/s30/'),
  Phone(brand: 'vivo', name: 'S50', releaseDate: '2025-12', chipset: '第三代骁龙8s', screen: '6.59英寸 OLED', battery: '6500mAh', sourceUrl: 'https://www.vivo.com/cn/phones/s50/'),
  Phone(brand: 'vivo', name: 'X Fold6', releaseDate: '2026-06', chipset: '天玑9500超能版', screen: '折叠屏 OLED', battery: '7000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/xfold6/'),
  Phone(brand: 'vivo', name: 'Y500', releaseDate: '2025-09', chipset: '天玑7300', screen: '6.67英寸 OLED', battery: '6000mAh', sourceUrl: 'https://www.vivo.com/cn/phones/y500/'),

  // ---------- 荣耀 ----------
  Phone(brand: '荣耀', name: 'Magic8 Pro', releaseDate: '2026-03', chipset: '第五代骁龙8至尊版', screen: '6.71英寸 OLED', battery: '5900mAh', sourceUrl: 'https://www.honor.com/cn/products/magic8-pro/'),
  Phone(brand: '荣耀', name: 'Magic V5', releaseDate: '2025-07', chipset: '骁龙8至尊版', screen: '7.95英寸 折叠屏 OLED', battery: '5820mAh', sourceUrl: 'https://www.honor.com/cn/products/magicv5/'),
  Phone(brand: '荣耀', name: '500', releaseDate: '2025-11', chipset: '骁龙8 Gen2', screen: '6.7英寸 OLED', battery: '8000mAh', sourceUrl: 'https://www.honor.com/cn/products/500/'),
  Phone(brand: '荣耀', name: '500 Pro', releaseDate: '2025-11', chipset: '骁龙8 Gen3', screen: '6.78英寸 OLED', battery: '6000mAh', sourceUrl: 'https://www.honor.com/cn/products/500pro/'),
  Phone(brand: '荣耀', name: 'Magic8', releaseDate: '2025-10', chipset: '骁龙8 Gen3', screen: '6.78英寸 OLED', battery: '5600mAh', sourceUrl: 'https://www.honor.com/cn/products/magic8/'),
  Phone(brand: '荣耀', name: 'GT Pro', releaseDate: '2025-09', chipset: '骁龙8 Gen3', screen: '6.78英寸 OLED', battery: '5800mAh', sourceUrl: 'https://www.honor.com/cn/products/gt-pro/'),

  // ---------- 一加 ----------
  Phone(brand: '一加', name: '一加 15', releaseDate: '2025-12', chipset: '第五代骁龙8至尊版', screen: '6.82英寸 2K AMOLED', battery: '6000mAh', sourceUrl: 'https://www.oneplus.com/cn/15/'),
  Phone(brand: '一加', name: 'Ace 6', releaseDate: '2025-10', chipset: '骁龙8至尊版', screen: '6.83英寸 1.5K OLED', battery: '7800mAh', sourceUrl: 'https://www.oneplus.com/cn/ace6/'),

  // ---------- 三星 ----------
  Phone(brand: '三星', name: 'Galaxy S26 Ultra', releaseDate: '2026-03', chipset: '骁龙8至尊版Gen5', screen: '6.9英寸 Dynamic AMOLED 2X', battery: '5000mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s26-ultra/'),
  Phone(brand: '三星', name: 'Galaxy S25 Ultra', releaseDate: '2025-02', chipset: '骁龙8至尊版', screen: '6.9英寸 Dynamic AMOLED 2X', battery: '5000mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s25-ultra/'),
  Phone(brand: '三星', name: 'Galaxy S25 FE', releaseDate: '2025-09', chipset: '骁龙8 Gen3', screen: '6.7英寸 AMOLED', battery: '4500mAh', sourceUrl: 'https://www.samsung.com/us/smartphones/galaxy-s25-fe/'),

  // ---------- realme ----------
  Phone(brand: 'realme', name: 'GT8', releaseDate: '2025-10', chipset: '骁龙8至尊版', screen: '6.79英寸 2K AMOLED', battery: '7000mAh', sourceUrl: 'https://www.realme.com/cn/gt8/'),
  Phone(brand: 'realme', name: 'GT8 Pro', releaseDate: '2025-10', chipset: '骁龙8至尊版Gen5', screen: '6.79英寸 2K AMOLED', battery: '7000mAh', sourceUrl: 'https://www.realme.com/cn/gt8pro/'),

  // ---------- Redmi ----------
  Phone(brand: 'Redmi', name: 'K90', releaseDate: '2025-10', chipset: '骁龙8至尊版', screen: '6.59英寸 OLED', battery: '7100mAh', sourceUrl: 'https://www.mi.com/redmik90/'),
  Phone(brand: 'Redmi', name: 'K90 Pro Max', releaseDate: '2025-10', chipset: '第五代骁龙8至尊版', screen: '6.9英寸 OLED', battery: '7560mAh', sourceUrl: 'https://www.mi.com/redmik90promax/'),
  Phone(brand: 'Redmi', name: 'K90 Pro', releaseDate: '2025-10', chipset: '骁龙8至尊版', screen: '6.67英寸 OLED', battery: '6400mAh', sourceUrl: 'https://www.mi.com/redmik90pro/'),

  // ---------- iQOO ----------
  Phone(brand: 'iQOO', name: '15', releaseDate: '2025-10', chipset: '骁龙8至尊版', screen: '6.78英寸 AMOLED', battery: '6000mAh', sourceUrl: 'https://www.iqoo.com/cn/phone-iqoo15/'),
];