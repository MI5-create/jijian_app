import 'package:flutter/material.dart';
// 复用公用组件（AppColors, LiquidGlassCard）
import 'home_page.dart'; 

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
      children: [
        // 顶部：头像与昵称
        LiquidGlassCard(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color.fromRGBO(69, 214, 255, 0.3), // primary 的透明版
                      Color.fromRGBO(155, 123, 255, 0.3), // violet 的透明版
                    ],
                  ),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.2),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.person_rounded,
                  size: 36,
                  color: AppColors.textOnGlass,
                ),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '数码爱好者',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textPrimary,
                        letterSpacing: -0.5,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      '专注探索科技与参数',
                      style: TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 16),

        // 免责声明
        LiquidGlassCard(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.shield_outlined, size: 16, color: AppColors.primary),
                  const SizedBox(width: 8),
                  const Text(
                    '免责声明',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Text(
                '本应用数据来源于各品牌官网及公开网络，仅供学习交流使用，如有误差欢迎纠错。',
                style: TextStyle(
                  fontSize: 13,
                  height: 1.5,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 16),

        // 设置列表
        LiquidGlassCard(
          padding: EdgeInsets.zero,
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.privacy_tip_outlined, color: AppColors.primary, size: 22),
                title: const Text('隐私政策', style: TextStyle(color: AppColors.textOnGlass, fontSize: 15)),
                trailing: const Icon(Icons.chevron_right, color: AppColors.textTertiary),
                onTap: () => _showGlassDialog(
                  context,
                  '隐私政策',
                  '本应用为纯本地工具，不收集您的任何个人身份信息。\n\n'
                  '1. 收藏数据仅保存在您的设备本地（SharedPreferences），不会上传服务器。\n'
                  '2. 应用不申请位置、相机、麦克风、通讯录等敏感权限。\n'
                  '3. 机型数据来源于各品牌官网与公开信息，仅作查询与学习参考。\n\n'
                  '如需清除收藏数据，卸载应用即可。',
                ),
              ),
              Divider(height: 1, color: Colors.white.withValues(alpha: 0.06), indent: 16, endIndent: 16),
              ListTile(
                leading: const Icon(Icons.info_outline_rounded, color: AppColors.primary, size: 22),
                title: const Text('关于机鉴', style: TextStyle(color: AppColors.textOnGlass, fontSize: 15)),
                trailing: const Icon(Icons.chevron_right, color: AppColors.textTertiary),
                onTap: () => _showGlassDialog(
                  context,
                  '关于机鉴',
                  '机鉴 · 手机图鉴\n\n'
                  '一个专注于「可核实机型资料」的本地资料库。收录主流品牌机型，'
                  '覆盖芯片、屏幕、电池、发布时间等结构化字段。\n\n'
                  '数据持续更新，以来源链接指向的原始页面为准。',
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 32),

        // 底部版本号
        const Center(
          child: Text(
            '当前版本：v1.0.1',
            style: TextStyle(
              fontSize: 12,
              color: AppColors.textTertiary,
              letterSpacing: 0.5,
            ),
          ),
        ),
      ],
    );
  }

  // 通用的深色玻璃弹窗方法
  void _showGlassDialog(BuildContext context, String title, String content) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface2,
        surfaceTintColor: Colors.transparent, // 去除 Material 3 默认染色
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: Colors.white.withValues(alpha: 0.1), width: 0.5),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
        ),
        content: SingleChildScrollView(
          child: Text(
            content,
            style: const TextStyle(fontSize: 13, height: 1.6, color: AppColors.textSecondary),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('我知道了', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}