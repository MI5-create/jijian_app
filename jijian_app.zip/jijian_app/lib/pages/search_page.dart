import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import '../models/phone_model.dart';
import '../controllers/favorites_controller.dart';
import 'home_page.dart'; 

class SearchPage extends StatefulWidget {
  final FavoritesController favorites;
  const SearchPage({super.key, required this.favorites});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final TextEditingController _controller = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  List<Phone> get _filteredPhones {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return allPhones;
    
    return allPhones.where((p) {
      return p.brand.toLowerCase().contains(q) ||
             p.name.toLowerCase().contains(q) ||
             p.chipset.toLowerCase().contains(q);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final results = _filteredPhones;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(30),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
              child: Container(
                height: 52,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: AppColors.glassFillMedium,
                  border: Border.all(color: AppColors.glassStrokeTop, width: 0.8),
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.search, color: AppColors.textSecondary, size: 20),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        style: const TextStyle(color: AppColors.textOnGlass, fontSize: 15),
                        decoration: const InputDecoration(
                          hintText: '搜索品牌、型号或芯片',
                          hintStyle: TextStyle(color: AppColors.textSecondary),
                          border: InputBorder.none,
                          isDense: true,
                        ),
                        onChanged: (val) {
                          setState(() => _query = val);
                        },
                      ),
                    ),
                    if (_query.isNotEmpty)
                      GestureDetector(
                        onTap: () {
                          _controller.clear();
                          setState(() => _query = '');
                          FocusScope.of(context).unfocus();
                        },
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.1),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.close, color: AppColors.textSecondary, size: 16),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),

        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
          child: Row(
            children: [
              Text(
                _query.isEmpty ? '全部机型' : '搜索结果',
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: AppColors.textSecondary),
              ),
              const Spacer(),
              Text(
                '${results.length} 款',
                style: const TextStyle(fontSize: 12, color: AppColors.textTertiary),
              ),
            ],
          ),
        ),

        Expanded(
          child: results.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.search_off, size: 64, color: AppColors.textTertiary),
                      SizedBox(height: 16),
                      Text(
                        '未找到相关机型',
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                      ),
                      SizedBox(height: 8),
                      Text(
                        '尝试更换品牌名、型号或芯片关键词',
                        style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                      ),
                    ],
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
                  physics: const AlwaysScrollableScrollPhysics(),
                  itemCount: results.length,
                  separatorBuilder: (context, index) => const SizedBox(height: 12),
                  itemBuilder: (context, i) {
                    final p = results[i];
                    return LiquidGlassCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('${p.brand} ${p.name}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: AppColors.textOnGlass)),
                                    const SizedBox(height: 4),
                                    Text('${p.displayReleaseDate} · ${p.chipset}', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                                  ],
                                ),
                              ),
                              ListenableBuilder(
                                listenable: widget.favorites,
                                builder: (context, child) => FavoriteButton(
                                  active: widget.favorites.isFavorite(p.id),
                                  onTap: () => widget.favorites.toggle(p.id),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}