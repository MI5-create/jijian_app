import 'package:flutter/material.dart';
import '../models/phone_model.dart';
import '../controllers/favorites_controller.dart';
// 复用公用组件（AppColors, LiquidGlassCard, FavoriteButton）
import 'home_page.dart'; 

class BrandPage extends StatefulWidget {
  final FavoritesController favorites;
  const BrandPage({super.key, required this.favorites});

  @override
  State<BrandPage> createState() => _BrandPageState();
}

class _BrandPageState extends State<BrandPage> {
  // 记录当前选中的品牌，为 null 时显示品牌网格
  String? _selectedBrand;
  late final Map<String, List<Phone>> _grouped;

  @override
  void initState() {
    super.initState();
    _grouped = <String, List<Phone>>{};
    for (final p in allPhones) {
      _grouped.putIfAbsent(p.brand, () => []).add(p);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_selectedBrand != null) {
      return _buildBrandDetail(_selectedBrand!);
    }
    return _buildBrandGrid();
  }

  // ============================================================
  // 视图一：品牌网格展示
  // ============================================================
  Widget _buildBrandGrid() {
    final brands = _grouped.keys.toList();

    return CustomScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      slivers: [
        // 顶部标题
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                const Text(
                  '品牌',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                    letterSpacing: -0.5,
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  '${brands.length} 个品牌',
                  style: const TextStyle(fontSize: 12, color: AppColors.textTertiary),
                ),
              ],
            ),
          ),
        ),
        // 副标题说明
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.fromLTRB(20, 0, 20, 16),
            child: Text(
              '点击品牌卡片，查看该品牌全部机型',
              style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
            ),
          ),
        ),
        // 网格列表
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.35,
            ),
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                final brand = brands[index];
                final phones = _grouped[brand] ?? [];
                final firstChar = brand.isNotEmpty ? brand.substring(0, 1) : '?';

                return LiquidGlassCard(
                  padding: EdgeInsets.zero,
                  onTap: () => setState(() => _selectedBrand = brand),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Stack(
                      children: [
                        // 背景首字母水印
                        Positioned(
                          right: -12,
                          bottom: -28,
                          child: Text(
                            firstChar,
                            style: TextStyle(
                              fontSize: 96,
                              height: 1,
                              fontWeight: FontWeight.w900,
                              color: Colors.white.withValues(alpha: 0.05),
                            ),
                          ),
                        ),
                        // 前景文字信息
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                brand,
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.textOnGlass,
                                ),
                              ),
                              Row(
                                children: [
                                  Container(
                                    width: 6,
                                    height: 6,
                                    decoration: BoxDecoration(
                                      color: AppColors.primary,
                                      shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                          color: AppColors.primary.withValues(alpha: 0.6),
                                          blurRadius: 6,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    '${phones.length} 款',
                                    style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500,
                                      color: AppColors.textSecondary,
                                    ),
                                  ),
                                  const Spacer(),
                                  const Icon(
                                    Icons.chevron_right_rounded,
                                    size: 18,
                                    color: AppColors.textTertiary,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
              childCount: brands.length,
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // 视图二：品牌专属机型列表
  // ============================================================
  Widget _buildBrandDetail(String brand) {
    final phones = _grouped[brand] ?? [];

    return Column(
      children: [
        // 顶部返回栏
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 12, 20, 8),
          child: Row(
            children: [
              SizedBox(
                width: 44,
                height: 44,
                child: IconButton(
                  onPressed: () => setState(() => _selectedBrand = null),
                  icon: const Icon(
                    Icons.arrow_back_ios_new_rounded,
                    size: 20,
                    color: AppColors.textPrimary,
                  ),
                  tooltip: '返回品牌列表',
                ),
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  brand,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.06),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withValues(alpha: 0.08), width: 0.6),
                ),
                child: Text(
                  '${phones.length} 款',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textSecondary,
                  ),
                ),
              ),
            ],
          ),
        ),
        // 机型列表
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
            physics: const AlwaysScrollableScrollPhysics(),
            itemCount: phones.length,
            separatorBuilder: (context, index) => const SizedBox(height: 12),
            itemBuilder: (context, i) {
              final p = phones[i];
              return LiquidGlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                p.name,
                                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: AppColors.textOnGlass),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${p.displayReleaseDate} · ${p.chipset}',
                                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                              ),
                            ],
                          ),
                        ),
                        ListenableBuilder(
                          listenable: widget.favorites,
                          builder: (context, child) => FavoriteButton(
                            active: widget.favorites.isFavorite(p.id),
                            onTap: () => widget.favorites.toggle(p.id),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _buildTag(p.screen),
                        const SizedBox(width: 8),
                        _buildTag(p.battery),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // 辅助标签组件
  Widget _buildTag(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
    );
  }
}