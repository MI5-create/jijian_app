import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import '../models/phone_model.dart';
import '../controllers/favorites_controller.dart';

// ============================================================
// ==== 以下为全局公用 UI 组件（供其他页面共用）====
// ============================================================

class AppColors {
  AppColors._();
  static const bgBase = Color(0xFF070B14);
  static const surface2 = Color(0xFF15223A);
  static const glassFillMedium = Color.fromRGBO(18, 30, 52, 0.62);
  static const glassStrokeTop = Color.fromRGBO(255, 255, 255, 0.28);
  static const primary = Color(0xFF45D6FF);
  static const violet = Color(0xFF9B7BFF);
  static const error = Color(0xFFFF6B81);
  
  static const textPrimary = Color(0xFFF4F8FF); 
  static const textSecondary = Color(0xFFB7C4D9);
  static const textTertiary = Color(0xFF7C8AA3);
  static const textOnGlass = Color(0xFFEAF2FF);
}

class LiquidGlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double borderRadius;
  final VoidCallback? onTap;

  const LiquidGlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderRadius = 20.0,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Widget content = Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.glassStrokeTop, Color.fromRGBO(255, 255, 255, 0.06)],
        ),
      ),
      padding: const EdgeInsets.all(0.5),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius - 0.5),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: AppColors.glassFillMedium,
              borderRadius: BorderRadius.circular(borderRadius - 0.5),
            ),
            child: child,
          ),
        ),
      ),
    );

    if (onTap != null) {
      return GestureDetector(onTap: onTap, child: content);
    }
    return content;
  }
}

class FavoriteButton extends StatelessWidget {
  final bool active;
  final VoidCallback onTap;
  const FavoriteButton({super.key, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 40,
        height: 40,
        child: Center(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 180),
            transitionBuilder: (child, animation) => ScaleTransition(scale: animation, child: child),
            child: Icon(
              active ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              key: ValueKey<bool>(active),
              size: 24,
              color: active ? AppColors.error : AppColors.textTertiary,
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// ==== 首页页面本体 ====
// ============================================================

class HomePage extends StatefulWidget {
  final FavoritesController favorites;
  const HomePage({super.key, required this.favorites});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late final Map<String, List<Phone>> _grouped;

  @override
  void initState() {
    super.initState();
    _grouped = <String, List<Phone>>{};
    for (final p in allPhones) {
      _grouped.putIfAbsent(p.brand, () => []).add(p);
    }
  }

  @override
  Widget build(BuildContext context) {
    final brands = _grouped.keys.toList();

    return ListView.builder(
      padding: const EdgeInsets.only(top: 20, bottom: 100),
      itemCount: brands.length,
      itemBuilder: (context, index) {
        final brand = brands[index];
        final phones = _grouped[brand] ?? [];
        
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
              child: Text(
                brand,
                style: const TextStyle(
                  fontSize: 24, 
                  fontWeight: FontWeight.bold, 
                  color: Colors.white,
                  letterSpacing: -0.5,
                ),
              ),
            ),
            ...phones.map((p) => Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
              child: LiquidGlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                p.name, 
                                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: AppColors.textOnGlass)
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${p.displayReleaseDate} · ${p.chipset}', 
                                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)
                              ),
                            ],
                          ),
                        ),
                        ListenableBuilder(
                          listenable: widget.favorites,
                          builder: (context, child) => FavoriteButton(
                            active: widget.favorites.isFavorite(p.id),
                            onTap: () => widget.favorites.toggle(p.id),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _buildChip(p.screen),
                        const SizedBox(width: 8),
                        _buildChip(p.battery),
                      ],
                    ),
                  ],
                ),
              ),
            )),
          ],
        );
      },
    );
  }

  Widget _buildChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
    );
  }
}